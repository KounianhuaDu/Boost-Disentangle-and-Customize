
BASE_MODEL_ROOT="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights"
MERGE_MODEL_ROOT="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/merge_root"
BASE_MODEL="Meta-Llama-3.1-8B-Instruct"
OUT_DIR="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/"
LORA="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/merge_methods/lora.json"

YAML='merge_methods/config/ties_merge.yml'
python merge_methods/run_merge.py \
    --base_model_root "$BASE_MODEL_ROOT" \
    --merge_model_root "$MERGE_MODEL_ROOT" \
    --base_model "$BASE_MODEL" \
    --models_to_merge final_0 final_1 final_2 \
    --out_dir "$OUT_DIR" \
    --yaml_file "$YAML" \
    --lora "$LORA"

YAML='merge_methods/config/dare_merge.yml'
python merge_methods/run_merge.py \
    --base_model_root "$BASE_MODEL_ROOT" \
    --merge_model_root "$MERGE_MODEL_ROOT" \
    --base_model "$BASE_MODEL" \
    --models_to_merge final_0 final_1 final_2 \
    --out_dir "$OUT_DIR" \
    --yaml_file "$YAML" \
    --lora "$LORA"

YAML='merge_methods/config/twin_merge.yml'
python merge_methods/run_merge.py \
    --base_model_root "$BASE_MODEL_ROOT" \
    --merge_model_root "$MERGE_MODEL_ROOT" \
    --base_model "$BASE_MODEL" \
    --models_to_merge final_0 final_1 final_2 \
    --out_dir "$OUT_DIR" \
    --yaml_file "$YAML" \
    --lora "$LORA"