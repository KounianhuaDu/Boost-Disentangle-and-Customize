#!/bin/bash
export CUDA_VISIBLE_DEVICES=0

INPUT_PATH="./train_data/final/APPS/"
DATA_FILE='0215'
OUTPUT_ROOT='./cluster_analysis'
ENCODER='/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights/codet5p-110m-embedding'
ARCH='llama3'
MODEL_WEIGHTS='/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights'
MODEL_NAME="Meta-Llama-3.1-8B-Instruct"

python enc_and_clustering.py --input_path "${INPUT_PATH}${DATA_FILE}" --output_path "${OUTPUT_PATH}/${DATA_FILE}" --encoder_path "${ENCODER}" --n_centroids "${N_CENTROIDS}"

for ((i=2; i<7; i++))
do
    python enc_and_clustering.py \
        --input_path "${INPUT_PATH}${DATA_FILE}" \
        --output_path "${OUTPUT_ROOT}/${i}" \
        --encoder_path "${ENCODER}" \
        --n_centroids "${i}"

done
