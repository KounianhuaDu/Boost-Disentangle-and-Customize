import torch
import torch.nn as nn
import torch.optim as optim
from torch.cuda import amp
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoModel, AutoTokenizer
import json
import argparse
import numpy as np
from HyperNet import HyperNet
from tqdm import tqdm
from modelscope import snapshot_download
import os
from tensorboardX import SummaryWriter


torch.manual_seed(7)
torch.cuda.manual_seed(7)


class Seq2SeqDataset(Dataset):
    def __init__(self, tokenizer, dataset, centroids, encoder_path):
        self.tokenizer = tokenizer
        self.max_length=2048
        self.tokenizer.pad_token = self.tokenizer.eos_token
        with open(dataset, "r") as f:
            self.dataset = json.load(f)

        self.encode_tokenizer = AutoTokenizer.from_pretrained(
            encoder_path, trust_remote_code=True
        )
        self.encode_model = AutoModel.from_pretrained(
            encoder_path, trust_remote_code=True, device_map="auto"
        )
        self.centroids_emb = torch.tensor(np.load(centroids)).to(
            self.encode_model.device
        )

    def encode(self, inputs):
        inputs = self.encode_tokenizer(
            inputs, padding="longest", truncation=True, return_tensors="pt"
        ).to(self.encode_model.device)
        with torch.no_grad():
            outputs = self.encode_model(**inputs)

        dis = nn.functional.normalize(outputs)
        dis = torch.matmul(self.centroids_emb, dis.t())

        return torch.cat([outputs.squeeze(0), dis.squeeze(1)])

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        item = self.dataset[idx]
        input_text = item["input"]
        target_text = item["output"]

        input_enc = self.encode(input_text)

        instruction = self.tokenizer(
            input_text,
            add_special_tokens=False
        )
        
        response = self.tokenizer(
            target_text,
            add_special_tokens=False
        )
        
        input_ids = instruction["input_ids"] + response["input_ids"] 
        #+ [self.tokenizer.pad_token_id]
        attention_mask = instruction["attention_mask"] + response["attention_mask"] + [1]
        labels = [-100] * len(instruction["input_ids"]) + response["input_ids"] 
        #+ [self.tokenizer.pad_token_id]
        
        if len(input_ids)< self.max_length:
            input_ids += [self.tokenizer.pad_token_id] * (self.max_length - len(input_ids))
            attention_mask += [0] * (self.max_length - len(attention_mask))
            labels += [-100] * (self.max_length - len(labels))
        
        input_ids = input_ids[:self.max_length]
        attention_mask = attention_mask[:self.max_length]
        labels = labels[:self.max_length]
        
        return input_enc, {
            "input_ids": torch.tensor(input_ids),
            "attention_mask": torch.tensor(attention_mask),
            "labels": torch.tensor(labels)
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parser For Arguments",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "--modelweight", default="../model_weights", help="Path to save the output"
    )
    parser.add_argument(
        "--cluster_root", default="./clustered_output", help="Path to save the output"
    )
    parser.add_argument(
        "--cluster", type=str, required=True
    )
    parser.add_argument(
        "--arch", default="llama3", help="Path to save the output"
    )
    parser.add_argument(
        "--layers", type=str, choices=['all', 'former', 'latter'], required=True
    )
    
    args = parser.parse_args()
    if args.arch == 'llama3':
        base_dir = os.path.join(args.modelweight, "Meta-Llama-3.1-8B-Instruct")

    merge_root = os.path.join(args.cluster_root, args.cluster, 'merge_root')
    #data_path = os.path.join(args.cluster_root, args.cluster, 'sft_data.json')
    cen_path = os.path.join(args.cluster_root, args.cluster, 'centroids.npy')
    enc_path = os.path.join(args.modelweight, "codet5p-110m-embedding")
    output_root = os.path.join(args.cluster_root, args.cluster, f'router_checkpoints_{args.layers}')
    
    os.makedirs(output_root, exist_ok=True)
    
    if args.layers == 'all':
        layers = range(10)
    elif args.layers == 'former':
        layers = range(3)
    elif args.layers == 'latter':
        layers = range(7, 10)
        
    router = HyperNet(base_dir, merge_root, ["final_0", "final_1", "final_2"], layer_range=layers)
    for name, param in router.named_parameters():
        if 'router_q' in name or 'router_v' in name:
            param.requires_grad = True
        else:
            param.requires_grad = False
            
    optimizer = optim.Adam(
        [param for param in router.parameters() if param.requires_grad == True], lr=1e-5
    )
    criterion = nn.CrossEntropyLoss()

    tokenizer = AutoTokenizer.from_pretrained(
        base_dir, use_fast=False, padding_side="left"
    )
    
    train_set = Seq2SeqDataset(tokenizer, os.path.join(args.cluster_root, args.cluster, 'sft_data.json'), cen_path, enc_path)
    train_loader = DataLoader(train_set, batch_size=1, shuffle=True)
    
    validation_set = Seq2SeqDataset(tokenizer, os.path.join(args.cluster_root, args.cluster, 'validation.json'), cen_path, enc_path)
    eval_loader = DataLoader(validation_set, batch_size=1, shuffle=True)
    
    train_dir = os.path.join(args.cluster_root, args.cluster, f"train_logs_{args.layers}")
    eval_dir = os.path.join(args.cluster_root, args.cluster, f"eval_logs_{args.layers}")
    train_writer = SummaryWriter(log_dir=train_dir)
    eval_writer = SummaryWriter(log_dir=eval_dir)
    
    best_epoch=0
    best_val = 10000000

    for epoch in range(5):
        router.train()
        total_loss = 0
        with tqdm(total=len(train_loader), dynamic_ncols=True) as t:
            for step, batch in enumerate(train_loader):
                #with torch.autocast(device_type="cuda", dtype=torch.float32):
                input_enc, json_line = batch
                input_enc = input_enc.to(router.device)
                input_ids = json_line['input_ids'].to(router.device)
                attn_mask = json_line['attention_mask'].to(router.device)
                labels = json_line['labels'].to(router.device)
                
                logits = router(input_enc, input_ids, attn_mask).logits
                
                loss = criterion(
                    logits.view(-1, logits.shape[-1]), labels.view(-1)
                ).sum()
                
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                
                total_loss += loss.item()
                
                train_iter = epoch * len(train_loader) * step
                
                t.update()
                t.set_postfix({
                    'train loss': f'{loss.item():.4f}'
                })
                
                train_writer.add_scalar('train_loss', loss.item(), train_iter)
                
        
        router.eval()
        eval_loss = 0
        with tqdm(total=len(eval_loader), dynamic_ncols=True) as t:
            for step, batch in enumerate(eval_loader):
                #with torch.autocast(device_type="cuda", dtype=torch.float32):
                input_enc, json_line = batch
                input_enc = input_enc.to(router.device)
                input_ids = json_line['input_ids'].to(router.device)
                attn_mask = json_line['attention_mask'].to(router.device)
                labels = json_line['labels'].to(router.device)
                
                logits = router(input_enc, input_ids, attn_mask).logits
                
                loss = criterion(
                    logits.view(-1, logits.shape[-1]), labels.view(-1)
                ).sum()
                
                eval_loss += loss.item()
                
                eval_iter = epoch * len(eval_loader) * step
                
                t.update()
                t.set_postfix({
                    'loss': f'{loss.item():.4f}'
                })
                eval_writer.add_scalar('eval_loss', loss.item(), eval_iter)
        
        if eval_loss < best_val:
            best_val = eval_loss
            best_epoch = epoch
            
        torch.save(router.state_dict(), os.path.join(output_root, f'./router_{epoch}'))
    
    print(f"Best epoch: {best_epoch}.")
