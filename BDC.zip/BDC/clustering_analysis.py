import numpy as np
import matplotlib.pyplot as plt 

def calculate_sse(centroids, samples, labels):
    """
    Inputs:
        centroids : (n_clusters, n_features)
        samples : (n_samples, n_features)
        labels : (n_samples,)
                                        
    Output
        sse
    """
     
    # 验证输入维度一致性
    assert samples.shape[1] == centroids.shape[1], "特征维度不一致"
    assert len(labels) == samples.shape[0], "标签数量与样本数量不一致"
    assert labels.max() < len(centroids), "存在无效的聚类标签"

    # 向量化计算：每个样本与其对应中心的差值
    diff = samples - centroids[labels]
    
    # 计算平方误差并求和（axis=1逐行求和，再总体求和）
    squared_errors = np.sum(np.square(diff), axis=1)
    sse = np.sum(squared_errors)
    
    return sse

def draw_figure(sses, ks):
    # 创建画布和坐标轴
    plt.figure(figsize=(10, 6), dpi=100)  # 设置图像大小和分辨率
    ax = plt.subplot(111)

    # 绘制折线（包含多种自定义参数）
    line1, = ax.plot(ks, sses, 
                    color='#FF6B6B',   # 十六进制颜色代码
                    linestyle='-',     # 实线
                    linewidth=2, 
                    marker='o',        # 圆形标记
                    markersize=6,
                    markevery=5,       # 每5个点显示一个标记
                    label='Cosine Distance')

    # 添加图例（调整位置和样式）
    '''legend = ax.legend(loc='upper right', 
                    frameon=True, 
                    shadow=True,
                    fontsize=12,
                    title='Curve Types')
    legend.get_title().set_fontsize('13')  # 设置图例标题字号'''

    # 设置坐标轴
    ax.set_xlabel('#Clusters', fontsize=14, labelpad=10)  # X轴标签
    ax.set_ylabel('SSE', fontsize=14, labelpad=10) # Y轴标签
    ax.set_title('Cluster Analysis', fontsize=16, pad=20)  # 主标题
    ax.grid(True, linestyle='--', alpha=0.7)  # 显示网格线

    '''# 设置坐标轴范围
    ax.set_xlim(0, 10)
    ax.set_ylim(-1.2, 1.2)'''

    # 设置刻度标签字号
    ax.tick_params(axis='both', which='major', labelsize=12)


    # 保存图像（支持PDF/SVG/PNG等多种格式）
    plt.savefig('line_plot.png', 
            bbox_inches='tight',  # 去除多余白边
            dpi=300)

    # 显示图形
    plt.show()

if __name__ == "__main__":
    import argparse
    import os
    
    parser = argparse.ArgumentParser(description="Parser For Arguments", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--clusters_path", default='./cluster_analysis', help="Path to save the clusters data.")
    
    args = parser.parse_args()
    
    sses = []
    for i in range(2,7):
        centroids = np.load(os.path.join(args.clusters_path, str(i), 'centroids.npy'))
        sample_embs = np.load(os.path.join(args.clusters_path, str(i), 'emb.npy'))
        labels = np.load(os.path.join(args.clusters_path, str(i), 'labels.npy'))
        
        sse = calculate_sse(centroids, sample_embs, labels)
        sses.append(sse)
    
    draw_figure(sses, ks=[2,3,4,5,6])
    
    
    
    
    
