#!/bin/bash
export CUDA_VISIBLE_DEVICES=0

ARCH="llama3"
MODEL="../model_weights"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/ties_merge/merged"
LOG="0215_APPS_ties_merge"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/dare_merge/merged"
LOG="0215_APPS_dare_merge"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/twin_merge/merged"
LOG="0215_APPS_twin_merge"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
