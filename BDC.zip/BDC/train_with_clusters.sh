#!/bin/bash
export CUDA_VISIBLE_DEVICES=0

INPUT_PATH="./train_data/final/CodeContest/"
DATA_FILE='all'
OUTPUT_PATH='./clustered_output/CodeContest'
ENCODER='/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights/codet5p-110m-embedding'
N_CENTROIDS=3
ARCH='llama3'
MODEL_WEIGHTS='/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights'
MODEL_NAME="Meta-Llama-3.1-8B-Instruct"

python enc_and_clustering.py --input_path "${INPUT_PATH}${DATA_FILE}" --output_path "${OUTPUT_PATH}/${DATA_FILE}" --encoder_path "${ENCODER}" --n_centroids "${N_CENTROIDS}"

for ((i=0; i<N_CENTROIDS; i++))
do
    python finetune/sft.py \
        --arch "${ARCH}" \
        --modelweight "${MODEL_WEIGHTS}" \
        --model_name "${MODEL_NAME}" \
        --model_out_root "${OUTPUT_PATH}/${DATA_FILE}" \
        --train_data_root "${OUTPUT_PATH}" \
        --data_name "sft_data_${i}.json" \
        --tuned_model_file "adapters_${i}" \
        --data_file "${DATA_FILE}"
done

python finetune/sft.py \
    --arch "${ARCH}" \
    --modelweight "${MODEL_WEIGHTS}" \
    --model_name "${MODEL_NAME}" \
    --model_out_root "${OUTPUT_PATH}/${DATA_FILE}" \
    --train_data_root "${OUTPUT_PATH}" \
    --data_name "sft_data.json" \
    --tuned_model_file "full_adapters" \
    --data_file "${DATA_FILE}"