import json
import numpy as np
import torch
# from sentence_transformers import SentenceTransformer, util
from transformers import AutoModel, AutoTokenizer
import os
import argparse
import faiss
from collections import defaultdict
from tqdm import tqdm

def encode(input_path, output_path, encoder_path, batch_size=16):
        os.environ["TOKENIZERS_PARALLELISM"] = "false"
        checkpoint = encoder_path
        tokenizer = AutoTokenizer.from_pretrained(checkpoint, trust_remote_code=True)
        model = AutoModel.from_pretrained(checkpoint, trust_remote_code=True, device_map = 'auto')

        with open(os.path.join(input_path, 'sft_data.json'), 'r') as f:
                data = json.load(f)

        documents = []
        for line in data:
               new_line = line['input'] + line['output']
               documents.append(new_line)

        embed_list = []
        for start_idx in tqdm(range(0, len(documents), batch_size)):
                batch_docs = documents[start_idx: min(start_idx + batch_size, len(documents))]
                inputs = tokenizer(batch_docs, padding='longest', truncation=True, return_tensors='pt').to(model.device)
                with torch.no_grad():
                        outputs = model(**inputs)
                embed_list.append(outputs)
        
        embeddings = torch.cat(embed_list, dim=0)
        embeddings = embeddings.cpu().numpy()

        np.save(os.path.join(output_path, 'emb.npy'), embeddings)

def faiss_clustering(output_path, n_centroids):
        embeddings = np.load(os.path.join(output_path, 'emb.npy'))
        d = embeddings.shape[1]
        # Normalization plus inner product equals cosine similarity
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        embeddings = embeddings / norms   
        index = faiss.IndexFlatIP(d)
        
        kmeans = faiss.Kmeans(d, n_centroids, verbose=True)
        kmeans.train(embeddings)
        
        np.save(os.path.join(output_path, 'centroids.npy'), kmeans.centroids)

def split_data(input_path, output_path):
        with open(os.path.join(input_path, 'sft_data.json'),'r') as f:
                data = json.load(f)
        with open(os.path.join(output_path, 'sft_data.json'), 'w') as f:
                json.dump(data, f)
        
        embeddings = np.load(os.path.join(output_path, 'emb.npy'))
        centroids = np.load(os.path.join(output_path, 'centroids.npy'))
        
        d = embeddings.shape[1]
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        embeddings = embeddings / norms
        embeddings = torch.tensor(embeddings) 
        centroids = torch.tensor(centroids) 
        distance = torch.matmul(embeddings, centroids.t()) 
        
        index=torch.argmax(distance, dim=1)
        
        np.save(os.path.join(output_path, 'labels.npy'), index.numpy())
        
        splited_data = defaultdict(list)
        for i, line in enumerate(data):
                splited_data[index[i].item()].append(line)
        
        for key, value in splited_data.items():
                print(f'Centroid {key}, got {len(value)} samples.')
                with open(os.path.join(output_path, f'sft_data_{key}.json'), 'w') as f:
                        json.dump(value, f)
                
def main(args):
        os.makedirs(args.output_path, exist_ok=True)
        encode(args.input_path, args.output_path, args.encoder_path)
        faiss_clustering(args.output_path, args.n_centroids)
        split_data(args.input_path, args.output_path)

        
if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description="Using different models to generate function")
    
    parser.add_argument("--input_path", default="./", help="Input data path")
    parser.add_argument("--output_path", default="./out", help="Output data path")
    parser.add_argument("--encoder_path", default="../model_weights/codet5p-110m-embedding", help="Encoder path")
    parser.add_argument("--n_centroids", type=int, default=3, help="Encoder path")
    
    args = parser.parse_args()
    
    main(args)
    

    
    
