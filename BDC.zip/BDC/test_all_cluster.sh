#!/bin/bash
export CUDA_VISIBLE_DEVICES=0

ARCH="llama3"
MODEL="../model_weights"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/adapters_0/final"
LOG="0215_apps_clustered_0"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/adapters_1/final"
LOG="0215_apps_clustered_1"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/adapters_2/final"
LOG="0215_apps_clustered_2"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/APPS/0215/full_adapters/final"
LOG="0215_apps_full_adapter"

python run_zero_shot.py --dataset APPS --level intro --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level inter --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset APPS --level comp --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
