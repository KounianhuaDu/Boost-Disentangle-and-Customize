from .ZeroShot import ZeroShot
from .CoT import CoT
from .Test import Test
