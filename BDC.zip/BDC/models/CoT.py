import numpy as np

from executors import AppsExecutor
from DebateChat import *


class CoT:
    def __init__(self, args):
        self.args = args
        self.sample_nums = 0
        self.gamma = 0.9
        
        if args.arch == 'llama':
            self.generator = LlamaChat(args.arch, args)
        elif args.arch == 'gpt':
            self.generator = GPTChat(args.arch, args)

        self.executor = AppsExecutor(args)
        
    def generate(self, problem_instance):
        self.cur_prob_instance = problem_instance
        raw_prompt = problem_instance["prompt"]
        cot_prompt = self.build_rationale_instruct(raw_prompt)
        cots = self.generator.generate_response_api(cot_prompt, top_k=1)
        cots = self.extract_cot(cots)
        code_prompt = self.build_code_instruct(raw_prompt, cots)
        message = self.generator.generate_response_api(code_prompt, top_k=1)
        pass_rate, accuracy, code = self.evaluate_code(message, problem_instance)

        output_dict = {
            "final_program": code,
            "pass_rate": pass_rate,
            "accuracy": accuracy,
        }

        return output_dict
    
    def return_demo(self, problem):
        demo = """
Problem:\n
Finding the longest palindrome substring.\n
\n
Step-by-step clues:\n
```json
[
{"Clue of Step 1": "For a substring, if it is a palindrome and the length is greater than 2, it is still a palindrome after the first and last letters are removed. According to this idea, we can use dynamic programming to solve this problem."},
{"Clue of Step 2": "Then we should consider the state transition function. We use P(i,j) to indicate whether the string composed of the i-th to j-th letters of the string s (denoted as as s[i:j]) is a palindrome string. s[i:j] is a palindrome only if s[i+1:j−1] is a palindrome and the i and j letters of s are the same."},
{"Clue of Step 3": "We also need to consider the boundary conditions in dynamic programming. For a substring of length 1, it is obviously a palindrome string; For a substring of length 2, it is a palindrome as long as its two letters are the same."},
{"Clue of Step 4": "We also need to consider the the cyclic order of dynamic programming. In the state transition equation, we are moving from a shorter string to a longer string."},
{"Clue of Step 5": "The final answer is the maximum length of the valid sub-strings."}
]
```
"""
        return demo
    
    def extract_cot(self, contents):
        thoughts = contents.split('```json')[1].split('```')[0]
        return thoughts
    
    def build_rationale_instruct(self, problem):
        demo = self.return_demo(problem)
        rationale_instruct = """
You will be given a problem description.\n
Please analyze the problem and generate step-by-step clues of how to solve the problem with executable python code.\n
An example of the problem-clues pairs is as below: \n
{}\n
You can refer to the above example and generate step-by-step clues for the given problem.\n
The problem:\n
{}\n
Now please generate the step-by-step clues of how to solve the problem and wrap them in json format.\n
""".format(demo, problem)
        return rationale_instruct
    
    def build_code_instruct(self, problem, cot):
        code_instruct = """
You will be given a problem desciption and the corresponding step-by-step clues of how to solve the problem.\n
Please analyze the problem and the clues to generate executable python code solution.\n
The problem:\n
{}\n
The clues:\n
{}\n
Answer:\n
""".format(problem, cot)
        return code_instruct

    def evaluate_code(self, generated_code, problem_instance, mode="test"):
        """
        Evaluate the generated code and calculate both pass rate and accuracy.
        """
        try:
            if "```python" in generated_code:
                generated_code = generated_code.split("```python")[1].split("```")[0]
            if "if __name__ ==" in generated_code:
                generated_code = generated_code.split("if __name__ ==")[0]
                generated_code = generated_code + "\n" + "main()"

            curr_res = self.executor.check_correctness(
                problem_instance, generated_code, mode
            )
            fixed = []
            for e in curr_res:
                if isinstance(e, np.ndarray):
                    e = e.item(0)
                if isinstance(e, np.bool_):
                    e = bool(e)
                fixed.append(e)
            curr_res = fixed

        except Exception as e:
            print(f"Exception during evaluation: {repr(e)}")
            curr_res = []

        # How to read results [-2] = compile error, [-1] = runtime error [False] = failed test case [True] = passed test case")
        assert isinstance(curr_res, list)
        pass_rate = np.mean(np.asarray(curr_res) > 0) if len(curr_res) > 0 else 0
        accuracy = 1.0 if pass_rate == 1.0 else 0.0
        return pass_rate, accuracy, generated_code