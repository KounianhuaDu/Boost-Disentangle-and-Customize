import numpy as np

from executors import AppsExecutor
from DebateChat import *


class Test:
    def __init__(self, args):
        self.args = args
        self.sample_nums = 0
        self.gamma = 0.9

        if args.arch == 'llama':
            self.generator = LlamaChat(args.arch, args)
        elif args.arch == 'gpt':
            self.generator = GPTChat(args.arch, args)

        self.executor = AppsExecutor(args)
        
    def generate(self, problem_instance, cot):
        self.cur_prob_instance = problem_instance
        raw_prompt = problem_instance["prompt"]
        raw_prompt = self.build_instruction(raw_prompt, cot)
        
        message = self.generator.generate_response_api(raw_prompt, top_k=1)

        pass_rate, accuracy, code = self.evaluate_code(message, problem_instance)

        output_dict = {
            "final_program": code,
            "pass_rate": pass_rate,
            "accuracy": accuracy,
        }

        return output_dict
    
    def build_instruction(self, prompt, cot):
        prompt = """You will be given a problem desciption.\nPlease analyze the problem and the corresponding clues to generate executable python code to solve the problem.\nThe problem:\n{}\n The clues:\n{}\n""".format(prompt, cot)
        return prompt

    def evaluate_code(self, generated_code, problem_instance, mode="test"):
        """
        Evaluate the generated code and calculate both pass rate and accuracy.
        """
        try:
            if "```python" in generated_code:
                generated_code = generated_code.split("```python")[1].split("```")[0]
            if "if __name__ ==" in generated_code:
                generated_code = generated_code.split("if __name__ ==")[0]
                generated_code = generated_code + "\n" + "main()"

            curr_res = self.executor.check_correctness(
                problem_instance, generated_code, mode
            )
            fixed = []
            for e in curr_res:
                if isinstance(e, np.ndarray):
                    e = e.item(0)
                if isinstance(e, np.bool_):
                    e = bool(e)
                fixed.append(e)
            curr_res = fixed

        except Exception as e:
            print(f"Exception during evaluation: {repr(e)}")
            curr_res = []

        # How to read results [-2] = compile error, [-1] = runtime error [False] = failed test case [True] = passed test case")
        assert isinstance(curr_res, list)
        pass_rate = np.mean(np.asarray(curr_res) > 0) if len(curr_res) > 0 else 0
        accuracy = 1.0 if pass_rate == 1.0 else 0.0
        return pass_rate, accuracy, generated_code