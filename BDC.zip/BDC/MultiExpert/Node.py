class MineDecisionNode:
    """
    Decision node class, labelled by a state

    Args:
        dp: default policy, used to prioritize and filter possible actions
    """

    def __init__(
        self,
        parent,
        task_instruct,
        thoughts_pool, #[clue1, clue 2, clue3] clue 4 
        #state
        is_terminal=False,
        generator=None,
        id=None,
        decision_memory="",
    ):
        self.id = id
        self.parent = parent
        self.task_instruct = task_instruct
        self.thoughts_pool = thoughts_pool
        #self.state = state
        self.value = None
        self.process_label = 0
        self.feedback = ''
        self.is_terminal = is_terminal
        '''if self.parent is None:  # Root node
            self.depth = 0
        else:  # Non root node
            self.depth = parent.depth + 1'''
        self.depth = len(self.thoughts_pool)
        self.generator = generator
        self.children = []

        self.explored_children = 0
        # this decision node should be visited at least once, otherwise p-uct makes no sense for this node
        self.visits = 1
        # used to save any information of the state
        # we use this for saving complete programs generated from it
        self.info = {}
        self.decision_memory = decision_memory


class MineChanceNode:
    """
    Chance node class, labelled by a state-action pair
    The state is accessed via the parent attribute
    """

    def __init__(self, parent, action_prob_type, chance_memory="", by_model=''):
        self.parent = parent
        self.action = action_prob_type[0]
        self.depth = parent.depth
        self.children = []
        self.prob = action_prob_type[1]  
        self.action_type = action_prob_type[2]  
        self.sampled_returns = []
        self.chance_memory = chance_memory
        self.by_model = by_model

    def expanded(self):
        return len(self.children) > 0

