import os
import sys

sys.path.append("..")

from DebateChat import GPTChat, YiChat, QwenChat, DeepSeekChat, ClaudeChat
from MultiExpert.Node import *
from executors import AppsExecutor
from .instruction import build_rationale_instruct
from collections import defaultdict, deque

from colorama import Fore, Back, Style, init
from math import sqrt, log
import numpy as np
import copy


class DebateMCTS:
    def __init__(self, args):
        self.gt = None

        self.experts = {}
        for model in args.teachers:
            if model == 0:
                self.experts["GPT"] = GPTChat(model, args)
            elif model == 1:
                self.experts["Yi"] = YiChat(model, args)
            elif model == 2:
                self.experts["claude"] = ClaudeChat(model, args)
            elif model == 3:
                self.experts["Qwen"] = QwenChat(model, args)
            elif model == 4:
                self.experts["DeepSeek"] = DeepSeekChat(model, args)

        self.decision_node_num = 0
        self.chance_node_num = 0
        self.root = None
        self.cached_reward = {}
        self.cached_value = {}
        self.cached_verbal_feedback = {}
        self.cur_prob_instance = None
        self.sample_times = []

        self.executor = AppsExecutor(args)

        self.ucb_base = args.ucb_base
        self.ucb_constant = args.ucb_constant
        self.gamma = 0.9
        self.num_expansions = 0

    ## Action selection policy related
    def chance_node_value(self, node, mode="best"):
        """
        Value of a chance node
        """
        if len(node.sampled_returns) == 0:
            return 0

        if mode == "best":
            # max return (reasonable because the model is deterministic?)
            return max(node.sampled_returns)
        elif mode == "sample":
            # Use average return
            return sum(node.sampled_returns) / len(node.sampled_returns)
        else:
            raise Exception(f"Unknown tree search mode {mode}")

    def var_p_ucb(self, node):
        """
        Upper Confidence Bound of a chance node, the ucb exploration weight is a variable
        """
        ucb_parameter = (
            log((node.parent.visits + self.ucb_base + 1) / self.ucb_base)
            + self.ucb_constant
        )
        return self.chance_node_value(node) + ucb_parameter * node.prob * sqrt(
            log(node.parent.visits)
        ) / (1 + len(node.sampled_returns))

    def var_p_uct_tree_policy(self, children):
        return max(children, key=self.var_p_ucb)

    ## Get reward related
    def convert_state_to_program(self, s):
        print(s)
        if "ANSWER:" in s:
            s = s.split("ANSWER:\n")[1]
        s = s.replace("<|endoftext|>", "")
        return s

    def get_reward(self, problem_instance, s, mode="train", with_verbal=False):
        output_str = self.convert_state_to_program(s)
        # 计算pass rate
        try:
            if "```python" in output_str:
                output_str = output_str.split("```python")[1].split("```")[0]

            if "if __name__ ==" in output_str:
                output_str = output_str.split("if __name__ ==")[0]
                output_str = output_str + "\n" + "main()"
            curr_res = self.executor.check_correctness(
                problem_instance, output_str, mode, with_verbal=with_verbal
            )  # with_verbal: curr_res=[[True/False, feedback_dict]]
            fixed = []
            verbal_feedbacks = []
            for e in curr_res:
                if isinstance(e, np.ndarray):
                    e = e.item(0)
                if isinstance(e, np.bool_):
                    e = bool(e)
                if with_verbal:
                    verbal_feedbacks.append(e[1])
                    e = e[0]
                fixed.append(e)

            curr_res = fixed
            # if not np.all(curr_res):
            #     print(f"Results were not all True: {curr_res}")
        except Exception as e:
            print(f"test framework exception = {repr(e)}{e}\n")
            curr_res = []

        # How to read results [-2] = compile error, [-1] = runtime error [False] = failed test case [True] = passed test case")
        assert isinstance(curr_res, list)
        pass_rate = np.mean(np.asarray(curr_res) > 0) if len(curr_res) > 0 else 0
        reward = pass_rate

        if mode == "train":
            self.cached_reward[s] = reward
            if with_verbal:
                self.cached_verbal_feedback[s] = verbal_feedbacks

        if with_verbal:
            return [reward, verbal_feedbacks]
        else:
            return reward

    def get_decision_state(self, problem, thoughts):
        if thoughts:
            rationale_instruct = problem + "\n".join(thoughts)
        else:
            rationale_instruct = problem
        return rationale_instruct

    def transition(self, problem_instance, task, thoughts, action, action_type):
        # task: task prompt
        # thoughts: list of strs
        # action: str
        # action_type: str

        print(Fore.RED + "Check Transition")
        flat_thoughts = "\n".join(thoughts)
        print(flat_thoughts)
        my_thoughts = copy.deepcopy(thoughts)

        if action_type == "refine":
            print("refine")
            if len(thoughts) == 0:
                my_thoughts.append(action)
            else:
                my_thoughts[-1] = action
        elif action_type == "detail":
            print("detail")
            my_thoughts.append(action)

        print(my_thoughts)
        flat_thoughts = "\n".join(my_thoughts)
        print(flat_thoughts)
        print(Fore.RED + "Check Transition End")

        next_state = self.get_decision_state(task, my_thoughts)
        reward = self.get_reward(problem_instance, next_state)

        self.cached_value[next_state] = reward

        return my_thoughts, reward

    def sample_actions(self, node):
        expand_prompt = self.get_decision_state(node.task_instruct, node.thoughts_pool)
        for expert_name, chat_func in self.experts.items():
            possible_actions, action_scores = chat_func.get_top_k_rationale_predict(
                expand_prompt, len(node.thoughts_pool)
            )
            action_types = ["detail"] * len(possible_actions)
            if not isinstance(possible_actions[0], str):
                possible_actions = [
                    chat_func.tokenizer.decode(action) for action in possible_actions
                ]
            # populate its children
            node.children += [
                MineChanceNode(
                    node,
                    (act, score, action_type),
                    chance_memory=node.decision_memory,
                    by_model=expert_name,
                )
                for act, score, action_type in zip(
                    possible_actions, action_scores, action_types
                )
            ]

    def get_process_label(self, node):
        if len(node.thoughts_pool) == 0:
            return 0
        elif len(node.thoughts_pool) == 1:
            if node.value > 0:
                return 1
            else:
                return -1
        else:
            last_value = node.parent.parent.value
            if last_value < node.value:
                return 1
            else:
                return -1

    def expand(self, problem_instance, num_new_nodes):
        problem_prompt = problem_instance["prompt"]
        problem_prompt = build_rationale_instruct(problem_prompt)

        root = MineDecisionNode(None, problem_prompt, [], id=self.decision_node_num)
        self.sample_actions(root)
        self.decision_node_num += 1

        for _ in range(num_new_nodes):
            rewards = []  # Rewards collected along the tree for the current rollout
            node = root  # Current node

            # Selection ###重点
            select = True
            while select:
                if type(node) == MineDecisionNode:
                    if node.is_terminal:
                        select = False
                    else:
                        node = self.var_p_uct_tree_policy(node.children)
                else:
                    # print(node.action)
                    next_thoughts_pool, reward = self.transition(
                        problem_instance,
                        node.parent.task_instruct,
                        node.parent.thoughts_pool,
                        node.action,
                        node.action_type,
                    )
                    rewards.append(reward)
                    new_state = True  # 如果树有很多层，这里的while循环会从根节点一层一层往下走，直到找到一个新的state_p
                    for i in range(len(node.children)):  # 其实chancenode只有一个child
                        if node.children[i].thoughts_pool == next_thoughts_pool:
                            # Shun: state_p already in the tree, point node to the corresponding Decision Node
                            node = node.children[i]
                            new_state = False
                            break
                    if (
                        new_state
                    ):  # 一开始如果是三个rollouts，就三个root的children都会经过这里
                        select = False  # Selected a ChanceNode

            # Expansion
            # If node is a decision node, then it must be a terminal node, do nothing here
            if type(node) == MineChanceNode:
                node.children.append(
                    MineDecisionNode(
                        node,
                        problem_prompt,
                        next_thoughts_pool,
                        # terminal,
                        generator=None,
                        id=self.decision_node_num,
                        decision_memory=node.chance_memory,
                    )
                )
                # if not self.args.mctsvalue in ["verbalMemory", "verbalMemoHistory"]:
                #    node.children[-1].__expand__()
                self.decision_node_num += 1
                node = node.children[-1]  # 就是新增加的decision node

            # Evaluation
            # now `rewards` collected all rewards in the ChanceNodes above this node
            assert type(node) == MineDecisionNode
            state = self.get_decision_state(problem_prompt, node.thoughts_pool)
            if not node.is_terminal:
                programs, estimates = self.get_estimate(state, problem_instance)

                tmp_tuple = [(x, y) for x, y in zip(programs, estimates)]
                sorted_res = sorted(tmp_tuple, key=lambda x: x[1])
                program = sorted_res[-1][0]
                estimate = sum(estimates) / len(estimates)
                node.value = estimate
                node.info["complete_program"] = (
                    program  # decision node的info里面存了这个节点的可能的complete_program
                )
            else:
                # the rewards are defined on terminating actions, the terminal states have no rewards
                estimate = 0
            self.sample_actions(node)
            # node.__expand__()

            # Backpropagation
            node.visits += 1
            node = node.parent
            assert type(node) == MineChanceNode
            while node:
                if len(rewards) != 0:
                    estimate = rewards.pop() + self.gamma * estimate
                node.sampled_returns.append(estimate)
                node.parent.visits += 1
                node = node.parent.parent

            # should finish backpropagating all the rewards back
            assert len(rewards) == 0
            # self.sample_times.append(time.time() - self.st)
        return root

    def get_estimate(self, state, problem_instance, num_trials=2):
        estimates = []
        programs = []
        for name, expander in self.experts.items():
            for i in range(num_trials):
                program = expander.get_rationale_predicted_sequence(
                    state, problem_instance["prompt"]
                )
                if not isinstance(program, str):
                    program = expander.tokenizer.decode(program)
                estimate = self.get_reward(problem_instance, program)
                programs.append(program)
                estimates.append(estimate)

        if tuple(state) not in self.cached_value.keys():
            self.cached_value[tuple(state)] = sum(estimates) / len(estimates)
        return programs, estimates

    def get_trajectory(
        self,
    ):
        pass

    def get_trace(self, root):
        node = root
        decision_to_chance = []
        chance_to_decision = []
        chance_id = -1
        chance_features = defaultdict(dict)
        decision_features = defaultdict(dict)
        queue = deque([node])
        while queue:
            node = queue.popleft()
            if type(node) == MineDecisionNode:
                """decision_features[node.id]["state"] = self.generator.tokenizer.decode(
                    get_decision_state(node.task_instruct, node.thoughts_pool)
                )"""
                decision_features[node.id]["state"] = self.get_decision_state(
                    node.task_instruct, node.thoughts_pool
                )
                decision_features[node.id]["value"] = node.value
            for child in node.children:
                queue.append(child)
                if type(child) == MineChanceNode:
                    chance_id += 1
                    decision_to_chance.append((node.id, chance_id))
                    chance_features[chance_id]["var_p_ucb"] = self.var_p_ucb(child)
                    """chance_features[chance_id]["action"] = (
                        self.generator.tokenizer.decode(child.action)
                    )"""
                    chance_features[chance_id]["action"] = child.action
                    chance_features[chance_id]["prob"] = child.prob
                    chance_features[chance_id]["by_model"] = child.by_model
                    if len(child.children) > 0:
                        next_decision = child.children[0]
                        chance_to_decision.append((chance_id, next_decision.id))

        trace_feats = (
            decision_to_chance,
            chance_to_decision,
            chance_features,
            decision_features,
        )
        return trace_feats

    def get_res(self, problem_instance):
        complete_programs_ids = list(self.cached_reward.keys())
        if complete_programs_ids is None or len(complete_programs_ids) == 0:
            return None
        complete_programs = [
            self.convert_state_to_program(s) for s in complete_programs_ids
        ]

        train_rewards = [self.cached_reward[s] for s in complete_programs_ids]
        test_rewards = [
            self.get_reward(problem_instance, s, mode="test")
            for s in complete_programs_ids
        ]
        best_idx = np.argmax(train_rewards)

        output_dict = {}
        output_dict["final_program"] = complete_programs[best_idx]
        output_dict["train_reward"] = train_rewards[best_idx]
        output_dict["test_reward"] = test_rewards[best_idx]

        output_dict["all_programs"] = complete_programs
        output_dict["all_train_rewards"] = train_rewards
        output_dict["all_test_rewards"] = test_rewards
        # output_dict["avg_sample_time"] = np.mean(np.array(self.sample_times))

        return output_dict

    def generate(self, problem_instance, num_new_nodes):
        # Initialization
        self.decision_node_num = 0
        self.chance_node_num = 0

        # Expansion
        root = self.expand(problem_instance, num_new_nodes)
        trace_feats = self.get_trace(root)
        output_dict = self.get_res(problem_instance)

        # Cache cleaning
        self.cached_reward = {}
        self.cached_value = {}

        return output_dict, trace_feats
