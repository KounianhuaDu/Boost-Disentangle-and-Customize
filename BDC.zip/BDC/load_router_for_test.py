import os
import json
from evaluate import *
import argparse
from models import ZeroShot
from data_handling import *
from colorama import Fore, Back, Style, init
from HyperNet import *
from transformers import AutoModelForCausalLM, AutoModel, AutoTokenizer
from executors import *
init(autoreset=True)
import torch


os.environ["TOKENIZERS_PARALLELISM"] = "false"

def evaluate_code(generated_code, problem_instance, mode="test"):
    """
    Evaluate the generated code and calculate both pass rate and accuracy.
    """
    try:
        if "```python" in generated_code:
            generated_code = generated_code.split("```python")[1].split("```")[0]
        if "if __name__ ==" in generated_code:
            generated_code = generated_code.split("if __name__ ==")[0]
            generated_code = generated_code + "\n" + "main()"

        curr_res = executor.check_correctness(
            problem_instance, generated_code, mode
        )
        fixed = []
        for e in curr_res:
            if isinstance(e, np.ndarray):
                e = e.item(0)
            if isinstance(e, np.bool_):
                e = bool(e)
            fixed.append(e)
        curr_res = fixed

    except Exception as e:
        print(f"Exception during evaluation: {repr(e)}")
        curr_res = []

    # How to read results [-2] = compile error, [-1] = runtime error [False] = failed test case [True] = passed test case")
    assert isinstance(curr_res, list)
    pass_rate = np.mean(np.asarray(curr_res) > 0) if len(curr_res) > 0 else 0
    accuracy = 1.0 if pass_rate == 1.0 else 0.0
    
    output_dict = {
        "final_program": generated_code,
        "pass_rate": pass_rate,
        "accuracy": accuracy,
    }
    return output_dict

def build_instruction(prompt):
    prompt = """You will be given a problem desciption.\nPlease analyze the problem and generate executable python code to solve the problem.\nThe problem:\n{}\n""".format(
        prompt
    )
    return prompt
    
def main(problem_indices, problems, output_path, rerun=False):
    for idx, problem_instance in zip(problem_indices, problems):
        print(idx)
        result_loc = os.path.join(output_path, f"{idx}")
        if not rerun:
            # if not forcing rerun, check if this experiment has run or failed before
            if os.path.exists(result_loc):
                print(f"Found {result_loc}, rerun not enabled, skipping")
                continue

        print(f"Generate Solution for Problem #{idx}")

        # Generate Code & Trace
        prompt = problem_instance["prompt"]
        inputs = encode_tokenizer(
            prompt, padding="longest", truncation=True, return_tensors="pt"
        ).to(encode_model.device)
        with torch.no_grad():
            outputs = encode_model(**inputs)
        dis = nn.functional.normalize(outputs)
        dis = torch.matmul(centroids_emb, dis.t())
        input_enc = torch.cat([outputs.squeeze(0), dis.squeeze(1)])

        full_prompt = build_instruction(prompt)
        
        router.eval()
        with torch.no_grad():
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                message = router.generate(input_enc.to(encode_model.device).unsqueeze(0), full_prompt)
        
        res = evaluate_code(message, problem_instance)
        
        if res:
            output_dict = res
        else:
            print(f"Cannot generate solution for Problem {idx}.")
            continue

        os.makedirs(result_loc, exist_ok=True)

        with open(os.path.join(result_loc, "res.json"), "w") as f:
            json.dump(
                {
                    "codes": output_dict["final_program"],
                    "pass_rate": output_dict["pass_rate"],
                },
                f,
            )


def evaluate(res_dir, eval_res):
    res_files = os.listdir(res_dir)
    rewards = []
    for res_file in res_files:
        with open(os.path.join(res_dir, res_file, "res.json"), "r") as f:
            data = json.load(f)
        rewards.append(data["pass_rate"])
    stat = {
        "pass_rate": 100 * np.mean(rewards),
        "ac": 100 * np.mean(np.array(rewards) == 1.0),
    }

    print(stat)

    with open(os.path.join(eval_res, "AllRes.json"), "w") as f:
        json.dump(stat, f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parser For Arguments",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    ## dataset related
    parser.add_argument(
        "--dataset", default="CodeContest", help="Dataset to use, default: APPS"
    )
    parser.add_argument("--data_path", default="./data", help="Path to save the data")
    parser.add_argument("--level", default="intro", help="Difficulty.")
    parser.add_argument("--mode", default="test")

    ## output & log
    parser.add_argument(
        "--out_path", default="./inference_res", help="Path to save the output"
    )
    parser.add_argument("--log_num", default="0", help="Log name.")
    parser.add_argument(
        "--algo",
        default="default",
        help="The algorithm used to train the tested model.",
    )
    parser.add_argument(
        "--res_path", default="./eval_res", help="Path to save the output"
    )

    ## backbone LLM
    parser.add_argument("--arch", default="gpt")
    parser.add_argument(
        "--modelweight",
        default="/ext0/hcchai/codemate",
        help="Path to save the model weights.",
    )

    ## vllm
    parser.add_argument("--vllm", action="store_true", help="If True, use vllm.")
    parser.add_argument("--device", default=1, type=int)

    ## resume checkpoint path
    parser.add_argument(
        "--resume",
        action="store_true",
        default=False,
        help="If True, load a tuned model.",
    )
    parser.add_argument(
        "--tuned_path",
        default="../tuned_models",
        help="Root path to save the checkpoints.",
    )
    parser.add_argument(
        "--model_file",
        default="",
        help="Checkpoint name. Valid only if resume is enabled.",
    )
    parser.add_argument(
        "--check_point",
        default="",
        help="Checkpoint name. Valid only if resume is enabled.",
    )

    ## LORA related
    parser.add_argument("--lora", action="store_true")
    parser.add_argument(
        "--lora_rank", type=int, default=8, help="LoRA rank for lora/qlora"
    )
    parser.add_argument(
        "--lora_alpha", type=int, default=16, help="LoRA alpha for lora/qlora"
    )
    parser.add_argument(
        "--lora_dropout", type=float, default=0.05, help="LoRA dropout for lora/qlora"
    )
    parser.add_argument(
        "--lora_target_modules",
        type=str,
        default="all",
        help="If 'default', uses peft defaults. Use 'all' for our best guess for Llama models",
    )

    ## To avoid error
    parser.add_argument(
        "--ts-mode",
        default="best",
        choices=["best", "sample"],
        help="Tree search mode within the evaluation step. `best` uses beam search, `sample` uses sampling.",
    )
    parser.add_argument(
        "--max_length",
        default=2048,
        type=int,
        help="The maximum number of tokens to generate.",
    )
    parser.add_argument(
        "--top-k-cache-steps",
        type=int,
        default=1024,
        help="Number of forward steps to cache top k caches, default 1024 means the whole horizon.",
    )
    parser.add_argument(
        "--width",
        default=3,
        type=int,
        help="The maximum number of children for any node.",
    )
    parser.add_argument(
        "--rerun",
        action="store_true",
        default=False,
        help="If True, rerun if the output file already exists.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        default=False,
        help="If True, rerun if the output file already exists.",
    )
    parser.add_argument("--difficulty", default="hard")

    args = parser.parse_args()

    print(args)

    output_path = os.path.join(
        args.out_path,
        args.arch,
        args.dataset,
        f"Router0216_ZeroShot_{args.arch}_{args.log_num}_{args.algo}_{args.dataset}_{args.level}",
    )
    
    print("output_path:", output_path)
    os.makedirs(output_path, exist_ok=True)

    # Dataset loading
    if args.dataset == "Ultra":
        dataset = UltraHandler()
        problems = dataset.problems
        problem_indices = range(len(problems))
    elif args.dataset == "APPS":
        if args.level == "intro":
            problem_indices = range(4000, 4100)
        elif args.level == "inter":
            problem_indices = range(100)
        elif args.level == "comp":
            problem_indices = range(3000, 3100)
        dataset = APPSHandler(
            args.data_path, "test", problem_indices, None, 'half'
        )
        problems = dataset.problems
    elif args.dataset == "CodeForce":
        dataset = CodeForceHandler(mode=args.mode)
        problems = dataset.problems
        problem_indices = range(len(problems))
    elif args.dataset == "CodeContest":
        dataset = CodeContestHandler(mode=args.mode, difficulty=args.level)
        problems = dataset.problems
        problem_indices = range(len(problems))
    else:
        raise NotImplementedError
    
    ###
    base_dir = "/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights/Meta-Llama-3.1-8B-Instruct"
    merge_root = "./clustered_output/CodeContest/all/merge_root"
    data_path = "./clustered_output/CodeContest/all/sft_data.json"
    cen_path = "./clustered_output/CodeContest/all/centroids.npy"
    enc_path = "/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights/codet5p-110m-embedding"

    router = HyperNet(base_dir, merge_root, ["final_0", "final_1", "final_2"])
    router.load_state_dict(torch.load('./clustered_output/CodeContest/all/router_checkpoints_old/router_4'))
    
    encode_tokenizer = AutoTokenizer.from_pretrained(
        enc_path, trust_remote_code=True
    )
    encode_model = AutoModel.from_pretrained(
        enc_path, trust_remote_code=True, device_map="auto"
    )
    centroids_emb = torch.tensor(np.load(cen_path)).to(
        encode_model.device
    )
    tokenizer = AutoTokenizer.from_pretrained(
        base_dir, use_fast=False, padding_side="left"
    )
    tokenizer.pad_token = tokenizer.eos_token
    
    executor = AppsExecutor(args)
    ###

    print("Model set.")
    print(f"Got {len(problems)} problems.")

    main(problem_indices, problems, output_path)

    evaluation_res = os.path.join(
        args.res_path, 
        f"Router0216_ZeroShot_{args.arch}_{args.log_num}_{args.dataset}_{args.level}"
    )

    os.makedirs(evaluation_res, exist_ok=True)
    evaluate(output_path, evaluation_res)
