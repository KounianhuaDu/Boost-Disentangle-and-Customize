import argparse
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.manifold import TSNE

embedding_path = './clustered_output/APPS/0215/emb.npy'

embedding_data = np.load(embedding_path)


tsne = TSNE(n_components=2).fit_transform(embedding_data)
plt.figure(figsize=(8, 6))
plt.scatter(tsne[:, 0], tsne[:, 1], label="APPS", s=20, alpha=0.7)

plt.title("T-SNE visualization of APPS data encoding")
plt.xlabel("T-SNE Component 1")
plt.ylabel("T-SNE Component 2")
plt.legend()
plt.savefig('apps.pdf', dpi=120)