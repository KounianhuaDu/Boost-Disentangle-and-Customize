#!/usr/bin/env bash
set -euo pipefail

export CUDA_VISIBLE_DEVICES=0

# This script runs the complete pipeline:
# 1. Data processing
# 2. SFT tuning
# 3. Evaluation (zero-shot inference)

# Adjust these paths as needed:

# args for data processing
DATASET="APPS"
IN_ROOT="../train_trace/APPS/" # Path to the traces
OUT_ROOT="../train_data/APPS" # Path to the first processed data (by problem dir)
FINAL_ROOT="../train_data/final/APPS" # Path to the final processed data
TRACE="0215"

# args for sft
DATA_FILE=$TRACE
ARCH="llama3"
MODEL_WEIGHT="../../model_weights" # Path of the original model weights
MODEL_NAME="Meta-Llama-3.1-8B-Instruct"
MODEL_TUNED_PATH="../tuned_models/0210" # Path to save the checkpoints
TUNED_MODEL_FILE_SFT="$MODEL_NAME-sft-codecontest" # The model to be sft tuned
TUNED_MODEL_FILE_P2T="$MODEL_NAME-p2t-codecontest"
TUNED_MODEL_FILE_T2S="$MODEL_NAME-t2s-codecontest"
DATA_NAME="sft_data.json"
P2T_DATA_NAME="p2t_data.json"
T2S_DATA_NAME="t2s_data.json"

# args for evaluation
EVAL_DATA_PATH="../data/"

# 1. Data Processing
# After data processing, the data will be stored in FINAL_ROOT/TRACE 
echo "Starting data processing..."
python ../DataScripts/process_data.py \
  --in_root "$IN_ROOT" \
  --out_root "$OUT_ROOT" \
  --final_root "$FINAL_ROOT" \
  --trace "$TRACE" \
  --dataset "$DATASET"
echo "Data processing complete."

# 2. SFT Tuning
# After SFT, the tuned model will be stored in MODEL_TUNED_PATH
#echo "Starting SFT tuning..."
#./sft.sh \
#    --arch "$ARCH" \
#    --modelweight "$MODEL_WEIGHT" \
#    --model_name "$MODEL_NAME" \
#    --model_out_root "$MODEL_TUNED_PATH" \
#    --train_data_root "$FINAL_ROOT" \
#    --data_file "$DATA_FILE" \
#    --tuned_model_file "$TUNED_MODEL_FILE_SFT"\
#    --data_name "$DATA_NAME" 
#echo "SFT tuning complete."

#echo "Starting P2T SFT tuning..."
#./sft.sh \
#    --arch "$ARCH" \
#    --modelweight "$MODEL_WEIGHT" \
#    --model_name "$MODEL_NAME" \
#    --model_out_root "$MODEL_TUNED_PATH" \
#    --train_data_root "$FINAL_ROOT" \
#    --data_file "$DATA_FILE" \
#    --tuned_model_file "$TUNED_MODEL_FILE_P2T"\
#    --data_name "$P2T_DATA_NAME" 
#echo "SFT tuning complete."

#echo "Starting T2S SFT tuning..."
#./sft.sh \
#    --arch "$ARCH" \
#    --modelweight "$MODEL_WEIGHT" \
#    --model_name "$MODEL_NAME" \
#    --model_out_root "$MODEL_TUNED_PATH" \
#    --train_data_root "$FINAL_ROOT" \
#    --data_file "$DATA_FILE" \
#    --tuned_model_file "$TUNED_MODEL_FILE_T2S"\
#    --data_name "$T2S_DATA_NAME" 
#echo "SFT tuning complete."
# 3. Evaluation (Zero-Shot Inference)
# echo "Starting SFT evaluation..."
#./zero_shot_eval.sh \
#    --dataset "APPS" \
#    --data_path "$EVAL_DATA_PATH" \
#    --arch "$ARCH" \
#    --modelweight "$MODEL_WEIGHT" \
#    --algo "sft" \
#    --tuned_path "$MODEL_TUNED_PATH" \
#    --model_file "$TUNED_MODEL_FILE_SFT" 
#echo "SFT Evaluation complete."

# 4. DPO Tuning
# After DPO, the tuned model will be stored in MODEL_TUNED_PATH
#echo "Starting DPO tuning..."
#./dpo.sh \
#    --arch "$ARCH" \
#    --modelweight "$MODEL_TUNED_PATH" \
#    --model_name "$TUNED_MODEL_FILE_SFT" \
#    --model_out_root "$MODEL_TUNED_PATH" \
#    --train_data_root "$FINAL_ROOT" \
#    --data_file "$DATA_FILE" \
#    --tuned_model_file "$TUNED_MODEL_FILE_DPO" 
#echo "DPO tuning complete."

# 5. Evaluation (Zero-Shot Inference)
# 
#echo "Starting DPO evaluation..."
#./zero_shot_eval.sh \
#    --dataset "APPS" \
#    --data_path "$EVAL_DATA_PATH" \
#    --arch "$ARCH" \
#    --modelweight "$MODEL_WEIGHT" \
#    --algo "dpo" \
#    --tuned_path "$MODEL_TUNED_PATH" \
#    --model_file "$TUNED_MODEL_FILE_DPO" 
#echo "DPO Evaluation complete."