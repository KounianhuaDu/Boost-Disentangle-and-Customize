#!/usr/bin/env bash
while [[ "$#" -gt 0 ]]; do
  case $1 in
    --arch) ARCH="$2"; shift ;;
    --modelweight) MODEL_WEIGHTS="$2"; shift ;;
    --model_name) MODEL_NAME="$2"; shift ;;
    --model_out_root) MODEL_OUT_ROOT="$2"; shift ;;
    --train_data_root) TRAIN_DATA_ROOT="$2"; shift ;;
    --data_file) DATA_FILE="$2"; shift ;;
    --tuned_model_file) TUNED_MODEL_FILE="$2"; shift ;;
    --data_name) DATA_NAME="$2"; shift ;;
    # may need to manually add more params if needed to change
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
  shift
done

python ../finetune/sft.py \
    --arch "$ARCH" \
    --modelweight "$MODEL_WEIGHTS" \
    --model_name "$MODEL_NAME" \
    --model_out_root "$MODEL_OUT_ROOT" \
    --train_data_root "$TRAIN_DATA_ROOT" \
    --data_file "$DATA_FILE" \
    --tuned_model_file "$TUNED_MODEL_FILE" \
    --data_name "$DATA_NAME"

# ## Backbone LLM
# parser.add_argument("--arch", default='llama3')

# ## Seed
# parser.add_argument("--seed", type=int, default=42)

# ## Lora config
# parser.add_argument("--lora_r", type=int, default=8, help="Lora R.")
# parser.add_argument("--lora_alpha", type=int, default=16, help="Lora alpha.")
# parser.add_argument("--lora_dropout", type=float, default=0.05, help="Lora dropout.")

# ## Training setup
# parser.add_argument("--lr", type=float, default=1e-3)
# parser.add_argument("--eval_steps", type=int, default=200)
# parser.add_argument("--save_steps", type=int, default=200)
# parser.add_argument("--lr_scheduler_type", type=str, default="linear")
# parser.add_argument("--epochs", type=int, default=5)
# parser.add_argument("--total_batch_size", type=int, default=64)
# parser.add_argument("--train_size", type=int, default=65536)
# parser.add_argument("--load_in_8bit", action="store_true", help="Load model 8 bit.")
# parser.add_argument("--per_device_eval_batch_size", type=int, default=1)

# parser.add_argument("--resume", action="store_true", default=False, help="Resume from a checkpoint.")
# parser.add_argument("--checkpoint", default="", help="Checkpoint name. Enable only if resume is true.")

# ## Path
# parser.add_argument("--modelweight", default="../model_weights", help="Path of the original model weights.")
# parser.add_argument("--model_out_root", default="../tuned_models", help="Path to save the tuned model weights.")
# parser.add_argument("--train_data_root", default="../train_data/final", help="Path of the training data.")

# parser.add_argument("--data_file", help="Path of the training data file.", required=True)
# parser.add_argument("--model_file", help="Name of the newly-saved checkpoint.", required=True)
