#!/usr/bin/env bash
while [[ "$#" -gt 0 ]]; do
  case $1 in
    --in_root) IN_ROOT="$2"; shift ;;
    --out_root) OUT_ROOT="$2"; shift ;;
    --final_root) FINAL_ROOT="$2"; shift ;;
    --trace) TRACE="$2"; shift ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
  shift
done

# Placeholder for actual processing:
python ../DataScripts/process_data.py \
  --in_root "$IN_ROOT" \
  --out_root "$OUT_ROOT" \
  --final_root "$FINAL_ROOT" \
  --trace "$TRACE"