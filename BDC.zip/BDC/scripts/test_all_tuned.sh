#!/bin/bash

MODEL_ROOT="../../model_weights/"
BASE_MODEL="Meta-Llama-3.1-8B-Instruct"
CHECKPOINTS_ROOT="../tuned_models/Meta-Llama-3.1-8B-Instruct-sft/"
START=1
END=34
DATAPATH='../data/'

for ((i=$START; i<=$END; i++)); do
    CHECK="${CHECKPOINTS_ROOT}checkpoint-${i}"
    echo $CHECK
    python ../run_zero_shot.py --dataset APPS --data_path "$DATAPATH" --arch llama3 --modelweight "$MODEL_ROOT" --resume --lora --check_point "$CHECK" --log_num "$CHECK"
done