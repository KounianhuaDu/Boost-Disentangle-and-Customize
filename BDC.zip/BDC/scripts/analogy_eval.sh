#!/usr/bin/env bash
while [[ "$#" -gt 0 ]]; do
  case $1 in
    -p) PRETRAINED_PATH="$2"; shift ;;
    -a) A_PATH="$2"; shift ;;
    -b) B_PATH="$2"; shift ;;
    -c) C_PATH="$2"; shift ;;
    -t) TARGET_PATH="$2"; shift ;;
    --arch) ARCH="$2"; shift ;;
    # may need to manually add more params if needed to change
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
  shift
done

python ../get_task_vector.py \
    -p "$PRETRAINED_PATH"\
    -a "$A_PATH"\
    -b "$B_PATH"\
    -c "$C_PATH"\
    -t "$TARGET_PATH"


CUDA_VISIBLE_DEVICES=0 python ../run_zero_shot.py \
    --arch "$ARCH" \
    --resume \
    --tuned_path "$TARGET_PATH" \
    --lora \
    --check_point "$TARGET_PATH/analogy.safetensors"
