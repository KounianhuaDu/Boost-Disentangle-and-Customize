#!/usr/bin/env bash
while [[ "$#" -gt 0 ]]; do
  case $1 in
    --dataset) DATASET="$2"; shift ;;
    --data_path) DATA_PATH="$2"; shift ;;
    --arch) ARCH="$2"; shift ;;
    --modelweight) MODEL_WEIGHTS="$2"; shift ;;
    --algo) ALGO="$2"; shift ;;
    --tuned_path) TUNED_PATH="$2"; shift ;;
    --model_file) MODEL_FILE="$2"; shift ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
  shift
done

python ../run_zero_shot.py \
      --dataset "$DATASET" \
      --data_path "$DATA_PATH" \
      --arch "$ARCH" \
      --modelweight "$MODEL_WEIGHTS" \
      --resume \
      --lora \
      --algo "$ALGO" \
      --tuned_path "$TUNED_PATH" \
      --model_file "$MODEL_FILE" 

# ## dataset related
# parser.add_argument("--dataset", default="APPS", help="Dataset to use, default: APPS")
# parser.add_argument("--data_path", default="./data", help="Path to save the data")

# ## output & log
# parser.add_argument("--out_path", default="./inference_res", help="Path to save the output")
# parser.add_argument("--log_num", default="0", help="Log name.")

# ## Device
# parser.add_argument("--gpu", type=int, default="0", help="Set GPU Ids : Eg: For CPU = -1, For Single GPU = 0")

# ## backbone LLM
# parser.add_argument("--arch", default='llama')
# parser.add_argument("--modelweight", default="../model_weights", help="Path to save the model weights.")

# ## vllm
# parser.add_argument("--vllm", action="store_true", default=False, help="If True, use vllm.")
# parser.add_argument("--device_num", default=2, type=int, help="If True, use vllm.")

# ## resume checkpoint path
# parser.add_argument("--resume", action="store_true", default=False, help="If True, load a tuned model.")
# parser.add_argument("--tuned_path", default="../tuned_models", help="Root path to save the checkpoints.")
# parser.add_argument("--model_file", default="", help="Checkpoint name. Valid only if resume is enabled.")
# parser.add_argument("--model_archive", default="", help="Checkpoint name. Valid only if resume is enabled.")

# ## LORA related
# parser.add_argument("--lora", type=bool, default=False, help="Enable LoRA. Must be same as the checkpoint")
# parser.add_argument("--lora_rank", type=int, default=64, help="LoRA rank for lora/qlora")
# parser.add_argument("--lora_alpha", type=int, default=16, help="LoRA alpha for lora/qlora")
# parser.add_argument("--lora_dropout", type=float, default=0.1, help="LoRA dropout for lora/qlora")
# parser.add_argument("--lora_target_modules", type=str, default="all",
#                     help="If 'default', uses peft defaults. Use 'all' for our best guess for Llama models")

# ## To avoid error
# parser.add_argument("--ts-mode", default="best", choices=["best", "sample"], help="Tree search mode within the evaluation step. `best` uses beam search, `sample` uses sampling.")
# parser.add_argument("--max_length", default=2048, type=int, help="The maximum number of tokens to generate.")
# parser.add_argument('--top-k-cache-steps', type=int, default=1024, help="Number of forward steps to cache top k caches, default 1024 means the whole horizon.")
# parser.add_argument("--width", default=3, type=int, help="The maximum number of children for any node.")
# parser.add_argument('--rerun', action='store_true', default=False, help="If True, rerun if the output file already exists.")
# parser.add_argument('--debug', action='store_true', default=False, help="If True, rerun if the output file already exists.")
