#!/usr/bin/env bash
set -euo pipefail

export CUDA_VISIBLE_DEVICES=1

# This script runs the complete pipeline:
# 1. Data processing
# 2. SFT tuning
# 3. Evaluation (zero-shot inference)

# Adjust these paths as needed:

# args for data processing
IN_ROOT="../train_trace/All/" # Path to the traces
OUT_ROOT="../train_data" # Path to the first processed data (by problem dir)
FINAL_ROOT="../train_data/All" # Path to the final processed data
TRACE="all"

# args for sft
DATA_FILE=$TRACE
ARCH="llama3"
MODEL_WEIGHT="../../model_weights" # Path of the original model weights
MODEL_NAME="Meta-Llama-3.1-8B-Instruct"
MODEL_TUNED_PATH="../tuned_models/0210" # Path to save the checkpoints
TUNED_MODEL_FILE_SFT="$MODEL_NAME-sft-all"
DATA_NAME="sft_data.json"

# 2. SFT Tuning
# After SFT, the tuned model will be stored in MODEL_TUNED_PATH
echo "Starting SFT tuning..."
./sft.sh \
    --arch "$ARCH" \
    --modelweight "$MODEL_WEIGHT" \
    --model_name "$MODEL_NAME" \
    --model_out_root "$MODEL_TUNED_PATH" \
    --train_data_root "$FINAL_ROOT" \
    --data_file "$DATA_FILE" \
    --tuned_model_file "$TUNED_MODEL_FILE_SFT"\
    --data_name "$DATA_NAME" 
echo "SFT tuning complete."
