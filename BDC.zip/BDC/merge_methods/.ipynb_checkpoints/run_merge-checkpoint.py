from email.mime import base
import torch
from collections import defaultdict, OrderedDict
import tqdm
import re
import torch.nn as nn
import copy
import sparsify
import utils
import json
import sys
import transformers
from transformers import AutoModelForCausalLM, AutoModelForSeq2SeqLM, AutoModelForSequenceClassification, AutoTokenizer
import os
import functools
from peft import LoraConfig,get_peft_model
from model import load_causallm
from collections import defaultdict, OrderedDict
from param import param
import torch.nn.functional as F 
import torch
from collections import defaultdict
import numpy as np
from merge import MergingMethod,LoraMergingMethod
import inspect
import datasets
import pandas as pd
from safetensors.torch import load_file
import argparse

@torch.inference_mode()
def run_merge(
    args,
):
    exclude_param = merge_config.get('exclude_param', None)
    if exclude_param and len(exclude_param):
        filter_func = lambda n,p : not any([
            re.match(exclude_pattern, n) 
            for exclude_pattern in exclude_param
        ])
    # \theta_t
    models_finetuned = {
        name: load_causallm(name) for name in args.models_to_merge
    }
    # \theta_*
    models_to_merge = [
        models_finetuned[name]
        for name in args.models_to_merge
    ]
    base_model = load_causallm(os.path.join(args.model_root, args.base_model))
    # tokenizer = AutoTokenizer.from_pretrained(args.base_model)

    args.base_model = param(base_model)
    args.models_to_merge = [param(m) for m in models_to_merge]
    for model in args.models_to_merge:
        model.filter(filter_func)
    args.base_model.filter(filter_func)

    # 3. merge
    merger = MergingMethod(**args)
    merge_method = getattr(merger, args.merge_method)
    merged_param = merge_method(**args)

    for n, p in merged_param.param_dict.items():
        utils.rsetattr(base_model, n, torch.nn.Parameter(p, requires_grad=False)) 

    base_model.save_pretrained(args.out_dir)

@torch.inference_mode()
def run_merge_lora(
    args,
    merge_config
):
    
    exclude_param = merge_config.get('exclude_param', None)
    if exclude_param and len(exclude_param):
        filter_func = lambda n,p : not any([
            re.match(exclude_pattern, n) 
            for exclude_pattern in exclude_param
        ])

    peft_config = LoraConfig(**json.load(open(args.lora)))

    def load(model_path):
        try:
            ans = torch.load(
                os.path.join(model_path, 'adapter_model.bin')
            )
        except:
            ans = load_file(os.path.join(model_path, 'adapter_model.safetensors'))
        return ans

    # \theta_t
    models_finetuned = {
        name: load(name) for name in args.models_to_merge
    }
    models_to_merge = [
        models_finetuned[name]
        for name in args.models_to_merge
    ]
    
    base_model = load_causallm(os.path.join(args.model_root, args.base_model))
    base_model = get_peft_model(base_model, peft_config, adapter_name='merged')

    args.base_model = param(base_model)
    
    args.models_to_merge = [param(m).to(base_model.device) for m in models_to_merge] #adapter model weights
    for model in args.models_to_merge:
        model.filter(filter_func)
    args.base_model.filter(filter_func)

    # 3. merge
    merger = LoraMergingMethod(**args)
    merge_method = getattr(merger, args.merge_method)
    merged_param = merge_method(**args)

    for n, p in merged_param.param_dict.items():
        n = n.replace('lora_B', 'lora_B.merged')
        n = n.replace('lora_A', 'lora_A.merged')
        utils.rsetattr(base_model, n, torch.nn.Parameter(p, requires_grad=False)) 
    
    base_model.merge_and_unload(progressbar=True)
    base_model.save_pretrained(args.out_dir)


def main(args):
    merge_config = utils.from_yaml(args.yaml)  
    if args.lora:
        run_merge_lora(args, merge_config)
    else:
        run_merge(args, merge_config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Parser For Arguments", formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    ## model paths
    parser.add_argument("--model_root", default="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/public/models/llms", help="Root directory of model weights.")
    parser.add_argument("--models_to_merge", default=["Qwen2.5-Coder-7B-Instruct","Qwen2.5-Math-7B-Instruct"], nargs='+', help="List of models to be merged.")
    parser.add_argument("--base_model", default="Qwen2.5-7B-Instruct", help="Base model to be merged on.")
    parser.add_argument("--out_dir", default="./merged_models", help="Directory of merged models.")
    
    ## merge config
    parser.add_argument("--yaml", required=True)
    parser.add_argument("--lora", action='store_true', default=False)
    
    args = parser.parse_args()
    
    print(args)
    
    main(args)