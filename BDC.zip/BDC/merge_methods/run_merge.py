from email.mime import base
import torch
from collections import defaultdict, OrderedDict
import tqdm
import re
import torch.nn as nn
import copy
import sparsify
import utils
import json
import sys
import transformers
from transformers import AutoModelForCausalLM, AutoModelForSeq2SeqLM, AutoModelForSequenceClassification, AutoTokenizer
import os
import functools
from peft import LoraConfig,get_peft_model
from model import load_causallm
from collections import defaultdict, OrderedDict
from param import param
import torch.nn.functional as F 
import torch
from collections import defaultdict
import numpy as np
from merge import MergingMethod,LoraMergingMethod
import inspect
import datasets
import pandas as pd
from safetensors.torch import load_file
import argparse

@torch.inference_mode()
def run_merge(
    args,
    merge_config
):
    exclude_param = merge_config.get('exclude_param', None)
    if exclude_param and len(exclude_param):
        filter_func = lambda n,p : not any([
            re.match(exclude_pattern, n) 
            for exclude_pattern in exclude_param
        ])
    # \theta_t
    models_finetuned = {
        name: load_causallm(name) for name in args.models_to_merge
    }
    # \theta_*
    models_to_merge = [
        models_finetuned[name]
        for name in args.models_to_merge
    ]
    print('Models to be merged loaded.')
    
    base_model = load_causallm(os.path.join(args.base_model_root, args.base_model))
    print('Base model loaded.')
    
    args.base_model = param(base_model)
    
    args.models_to_merge = [param(m).to(base_model.device) for m in models_to_merge]
    for model in args.models_to_merge:
        model.filter(filter_func)
    args.base_model.filter(filter_func)

    # 3. merge
    inputs = {
        attr: getattr(args, attr) for attr in dir(args)
    }
    merge_config.update(inputs)
    
    merger = MergingMethod(**merge_config)
    merge_method = getattr(merger, merge_config['merge_method'])
    merged_param = merge_method(**merge_config)

    for n, p in merged_param.param_dict.items():
        utils.rsetattr(base_model, n, torch.nn.Parameter(p, requires_grad=False)) 

    base_model.save_pretrained(os.path.join(args.out_dir, merge_config['merge_method']))
    
@torch.inference_mode()
def run_full_merge(
    args,
    merge_config
):
    exclude_param = merge_config.get('exclude_param', None)
    if exclude_param and len(exclude_param):
        filter_func = lambda n,p : not any([
            re.match(exclude_pattern, n) 
            for exclude_pattern in exclude_param
        ])

    peft_config = LoraConfig(**json.load(open(args.lora)))

    def load_and_merge(model_path, peft_config):
        base_model = load_causallm(os.path.join(args.base_model_root, args.base_model))
        base_model = get_peft_model(base_model, peft_config)
        print('Base model loaded.')
        
        model = PeftModel.from_pretrained(base_model, model_path)
        model = model.merge_and_unload()
        return model
    
    # \theta_t
    models_finetuned = {
        name: load_and_merge(name) for name in args.models_to_merge
    }
    # \theta_*
    models_to_merge = [
        models_finetuned[name]
        for name in args.models_to_merge
    ]
    print('Models to be merged loaded.')
    
    base_model = models_to_merge[0]
    models_to_merge = models_to_merge[1:]
    
    args.base_model = param(base_model)
    
    args.models_to_merge = [param(m).to(base_model.device) for m in models_to_merge]
    for model in args.models_to_merge:
        model.filter(filter_func)
    args.base_model.filter(filter_func)

    # 3. merge
    inputs = {
        attr: getattr(args, attr) for attr in dir(args)
    }
    merge_config.update(inputs)
    
    merger = MergingMethod(**merge_config)
    merge_method = getattr(merger, merge_config['merge_method'])
    merged_param = merge_method(**merge_config)

    for n, p in merged_param.param_dict.items():
        utils.rsetattr(base_model, n, torch.nn.Parameter(p, requires_grad=False)) 

    base_model.save_pretrained(os.path.join(args.out_dir, merge_config['merge_method']))
    
@torch.inference_mode()
def run_merge_lora(
    args,
    merge_config
):
    
    exclude_param = merge_config.get('exclude_param', None)
    if exclude_param and len(exclude_param):
        filter_func = lambda n,p : not any([
            re.match(exclude_pattern, n) 
            for exclude_pattern in exclude_param
        ])

    peft_config = LoraConfig(**json.load(open(args.lora)))

    def load(model_path):
        try:
            ans = torch.load(
                os.path.join(args.merge_model_root, model_path, 'adapter_model.bin')
            )
        except:
            ans = load_file(os.path.join(args.merge_model_root, model_path, 'adapter_model.safetensors'))
        return ans

    base_model = load_causallm(os.path.join(args.base_model_root, args.base_model))
    base_model = get_peft_model(base_model, peft_config, adapter_name='merged')
    print('Base model loaded.')
    
    # \theta_t
    models_finetuned = {
        name: load(name) for name in args.models_to_merge
    }
    models_to_merge = [
        models_finetuned[name]
        for name in args.models_to_merge
    ]
    print('Models to be merged loaded.')
    
    args.base_model = param(base_model, device=base_model.device)
    args.models_to_merge = [param(m, device=base_model.device) for m in models_to_merge] #adapter model weights
    print('Prepare params process done. ')
    
    for model in args.models_to_merge:
        model.filter(filter_func)
    args.base_model.filter(filter_func)

    # 3. merge
    inputs = {
        attr: getattr(args, attr) for attr in dir(args)
    }
    merge_config.update(inputs)
    
    merger = LoraMergingMethod(**merge_config)
    merge_method = getattr(merger, merge_config['merge_method'])
    merged_param = merge_method(**merge_config)

    for n, p in merged_param.param_dict.items():
        n = n.replace('lora_B', 'lora_B.merged')
        n = n.replace('lora_A', 'lora_A.merged')
        utils.rsetattr(base_model, n, torch.nn.Parameter(p, requires_grad=False).to(base_model.device)) 
    
    base_model.merge_and_unload(progressbar=True)
    print(base_model)
    base_model.save_pretrained(os.path.join(args.out_dir, merge_config['merge_method']))


def main(args):
    merge_config = utils.from_yaml(args.yaml_file)  
    '''if args.lora:
        run_merge_lora(args, merge_config)
    else:
        run_full_merge(args, merge_config)'''
    run_merge_lora(args, merge_config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Parser For Arguments", formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    ## model paths
    parser.add_argument("--base_model_root", default="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/model_weights", help="Root directory of model weights.")
    parser.add_argument("--merge_model_root", default="../../tuned_models/Meta-Llama-3.1-8B-Instruct-sft", help="Root directory of merge model weights.")
    
    parser.add_argument("--models_to_merge", default=["checkpoint-6","checkpoint-7"], nargs='+', help="List of models to be merged.")
    parser.add_argument("--base_model", default="Meta-Llama-3.1-8B-Instruct", help="Base model to be merged on.")
    parser.add_argument("--out_dir", default="./merged_models", help="Directory of merged models.")
    
    ## merge config
    parser.add_argument("--yaml_file", required=True)
    parser.add_argument("--lora", type=str, default='lora.json')
    
    ## For task-arithmetic
    parser.add_argument("--scaling", type=float, default=0.7)
    
    ## For dare-merge
    parser.add_argument("--mask_rate", type=float, default=0.7)
    parser.add_argument("--mask_scale", type=float, default=1.0)
    parser.add_argument("--mask_strategy", type=str, default='bernoulli')
    
    args = parser.parse_args()
    args.models_name = args.models_to_merge
    args.src_merge = args.models_to_merge
    
    print(args)
    
    main(args)