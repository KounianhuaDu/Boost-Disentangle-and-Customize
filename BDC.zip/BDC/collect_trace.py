import time
from MultiExpert.Debate import DebateMCTS
from data_handling import *
import json
import matplotlib as mpl
import networkx as nx
from matplotlib import pyplot as plt
from collections import defaultdict
from evaluate import *
import argparse
from colorama import Fore, Back, Style, init
import numpy as np

init(autoreset=True)
import torch


def main(problem_indices, problems, model, output_path, num_new_nodes, rerun):
    for idx, problem_instance in zip(problem_indices, problems):
        print(idx)
        result_loc = os.path.join(output_path, f"{idx}")
        if not rerun:
            # if not forcing rerun, check if this experiment has run or failed before
            if os.path.exists(result_loc):
                print(f"Found {result_loc}, rerun not enabled, skipping")
                continue

        print(f"Generate Solution for Problem #{idx}")

        # Generate Code & Trace
        res = model.generate(problem_instance, num_new_nodes)
        if res:
            output_dict, trace_feat = res
        else:
            print(f"Cannot generate solution for Problem {idx}.")
            continue
        
        os.makedirs(result_loc, exist_ok=True)
        
        with open(os.path.join(result_loc, 'res.json'), "w") as f:
            json.dump({
                'codes': output_dict['final_program'], 'rewards': output_dict['all_test_rewards'], 'train rewards': output_dict['all_train_rewards']
            }, f)
        with open(os.path.join(result_loc, 'trace.json'), "w") as f:
            json.dump({'decision_to_chance': trace_feat[0], 'chance_to_decision': trace_feat[1], 'chance_features': trace_feat[2], 'decision_features': trace_feat[3]}, f)

        

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Parser For Arguments", formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    ## dataset related
    parser.add_argument("--dataset", default="APPS", help="Dataset to use, default: APPS")
    parser.add_argument("--data_path", default="./data", help="Path to save the data")
    parser.add_argument("--st", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)

    ## output & log
    parser.add_argument("--out_path", default="./train_trace", help="Path to save the output")
    parser.add_argument("--res_path", default="./trace_eval_res", help="Path to save the output")
    
    parser.add_argument("--log_num", default="0", help="Log name.")

    ## Device
    parser.add_argument("--gpu", type=int, default="0", help="Set GPU Ids : Eg: For CPU = -1, For Single GPU = 0")

    ## backbone LLM
    parser.add_argument("--experts", default='[0,2]', type=str)
    parser.add_argument("--modelweight", default="../../model_weights", help="Path to save the model weights.")
    parser.add_argument("--vllm", action="store_true", default=False, help="If True, use vllm.")
    
    ## resume checkpoint path
    parser.add_argument("--resume", action="store_true", default=False, help="If True, load a tuned model.")
    parser.add_argument("--tuned_path", default="../tuned_models", help="Root path to save the checkpoints.")
    parser.add_argument("--model_file", default="", help="Checkpoint name. Valid only if resume is enabled.")

    ## To avoid error
    parser.add_argument("--ts-mode", default="best", choices=["best", "sample"], help="Tree search mode within the evaluation step. `best` uses beam search, `sample` uses sampling.")
    parser.add_argument("--max_length", default=2048, type=int, help="The maximum number of tokens to generate.")
    parser.add_argument('--top-k-cache-steps', type=int, default=1024, help="Number of forward steps to cache top k caches, default 1024 means the whole horizon.")
    parser.add_argument("--width", default=3, type=int, help="The maximum number of children for any node.")
    parser.add_argument("--ucb-base", default=10., type=float)
    parser.add_argument("--ucb-constant", default=4., type=float)
    parser.add_argument("--rollout", default=16, type=int, help="Number of rollouts.")

    parser.add_argument('--rerun', action='store_true', default=False, help="If True, rerun if the output file already exists.")
    parser.add_argument('--debug', action='store_true', default=False, help="If True, rerun if the output file already exists.")
    parser.add_argument("--public-cases-type", type=str, default='half', help="Number of public test cases to use for evaluation.")
    
    args = parser.parse_args()

    print(args)

    args.teachers = eval(args.experts)

    log_name = '_'.join([str(ch) for ch in args.teachers])
    output_path = os.path.join(
        args.out_path, args.dataset, f"DebateMCTS_{log_name}_{args.log_num}"
    )
    if args.resume:
        output_path += "_tuned"
    print("output_path:", output_path)
    os.makedirs(output_path, exist_ok=True)

    if args.gpu >= 0 and torch.cuda.is_available():
        args.device = 'cuda:{}'.format(args.gpu)
    else:
        args.device = 'cpu'
    print(args)

    # Dataset loading
    if args.dataset == 'Ultra':
        dataset = UltraHandler()
        problems = dataset.problems
        problem_indices = range(len(problems))
    elif args.dataset == 'APPS':
        problem_indices = range(args.st, args.end)
        dataset = APPSHandler(args.data_path, 'test', problem_indices, None, args.public_cases_type)
        problems = dataset.problems
    elif args.dataset == 'CodeForce':
        dataset = CodeForceHandler(mode = 'train')
        problems = dataset.problems
        problem_indices = range(len(problems))
    elif args.dataset == "CodeContest":
        dataset = CodeContestHandler(mode = 'train')
        problems = dataset.problems
        problem_indices = range(len(problems))
    else:
        raise NotImplementedError

    model = DebateMCTS(args)

    print("Model set.")

    main(problem_indices, problems, model, output_path, args.rollout, args.rerun)

    evaluation_res = os.path.join(args.res_path, f"DebateMCTS_{log_name}_{args.log_num}")
    os.makedirs(evaluation_res, exist_ok=True)

    get_exp_results(output_path, evaluation_res)