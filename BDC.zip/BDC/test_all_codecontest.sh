#!/bin/bash
export CUDA_VISIBLE_DEVICES=0

ARCH="llama3"
MODEL="../model_weights"

CHECK="/inspire/hdd/ws-f4d69b29-e0a5-44e6-bd92-acf4de9990f0/public-project/zhangweinan-24046/dk/Multi-Teacher-Tree-Alignment-master/clustered_output/DebateMCTS_0_0/adapters_0/final"
LOG="clustered_0"

python run_zero_shot.py --dataset CodeContest --level easy --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"
python run_zero_shot.py --dataset CodeContest --level hard --modelweight "$MODEL" --arch "$ARCH" --resume --lora --check_point "$CHECK" --log_num "$LOG"

