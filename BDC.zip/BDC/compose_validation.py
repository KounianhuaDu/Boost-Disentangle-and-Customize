import os
import json

def compose_pair(prob_dir):
    with open(os.path.join(prob_dir, 'solutions.json'), 'r') as f:
        data = json.load(f)
        output = data[0]
        
    with open(os.path.join(prob_dir, 'question.txt'), 'r') as f:
        inputs = f.read()

    return {"input": inputs, "output":output}

def compose_validation(problem_idxs, problem_root):
    validation_set=[]
    for idx in problem_idxs:
        prob_dir = os.path.join(problem_root, f"{idx:04d}")
        try:
            with open(os.path.join(prob_dir, 'solutions.json'), 'r') as f:
                data = json.load(f)
                output = data[0]
                
            with open(os.path.join(prob_dir, 'question.txt'), 'r') as f:
                inputs = f.read()
        
            validation_set.append({"input": inputs, "output":output})
        except:
            print(f"{idx} not parsed.")
    print(f"Total {len(validation_set)} problems remaining.")
    return validation_set

import random
problem_idxs = list(random.sample(range(5000), 50))
problem_root = './data/APPS/train/'
data = compose_validation(problem_idxs, problem_root)
with open('validation.json', 'w') as f:
    json.dump(data, f)