from models import ZeroShot
from data_handling import *
import json
from evaluate import *
import argparse
from colorama import Fore, Back, Style, init

init(autoreset=True)
import torch


def main(problem_indices, problems, model, output_path, rerun):
    for idx, problem_instance in zip(problem_indices, problems):
        print(idx)
        result_loc = os.path.join(output_path, f"{idx}")
        if not rerun:
            # if not forcing rerun, check if this experiment has run or failed before
            if os.path.exists(result_loc):
                print(f"Found {result_loc}, rerun not enabled, skipping")
                continue

        print(f"Generate Solution for Problem #{idx}")

        # Generate Code & Trace
        res = model.generate(problem_instance)
        if res:
            output_dict = res
        else:
            print(f"Cannot generate solution for Problem {idx}.")
            continue

        os.makedirs(result_loc, exist_ok=True)

        with open(os.path.join(result_loc, "res.json"), "w") as f:
            json.dump(
                {
                    "codes": output_dict["final_program"],
                    "pass_rate": output_dict["pass_rate"],
                },
                f,
            )


def evaluate(res_dir, eval_res):
    res_files = os.listdir(res_dir)
    rewards = []
    for res_file in res_files:
        with open(os.path.join(res_dir, res_file, "res.json"), "r") as f:
            data = json.load(f)
        rewards.append(data["pass_rate"])
    stat = {
        "pass_rate": 100 * np.mean(rewards),
        "ac": 100 * np.mean(np.array(rewards) == 1.0),
    }

    print(stat)

    with open(os.path.join(eval_res, "AllRes.json"), "w") as f:
        json.dump(stat, f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parser For Arguments",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    ## dataset related
    parser.add_argument(
        "--dataset", default="CodeContest", help="Dataset to use, default: APPS"
    )
    parser.add_argument("--data_path", default="./data", help="Path to save the data")
    parser.add_argument("--level", default="intro", help="Difficulty.")
    parser.add_argument("--mode", default="test")

    ## output & log
    parser.add_argument(
        "--out_path", default="./inference_res", help="Path to save the output"
    )
    parser.add_argument("--log_num", default="0", help="Log name.")
    parser.add_argument(
        "--algo",
        default="default",
        help="The algorithm used to train the tested model.",
    )
    parser.add_argument(
        "--res_path", default="./eval_res", help="Path to save the output"
    )

    ## backbone LLM
    parser.add_argument("--arch", default="gpt")
    parser.add_argument(
        "--modelweight",
        default="/ext0/hcchai/codemate",
        help="Path to save the model weights.",
    )

    ## vllm
    parser.add_argument("--vllm", action="store_true", help="If True, use vllm.")
    parser.add_argument("--device", default=1, type=int)

    ## resume checkpoint path
    parser.add_argument(
        "--resume",
        action="store_true",
        default=False,
        help="If True, load a tuned model.",
    )
    parser.add_argument(
        "--tuned_path",
        default="../tuned_models",
        help="Root path to save the checkpoints.",
    )
    parser.add_argument(
        "--model_file",
        default="",
        help="Checkpoint name. Valid only if resume is enabled.",
    )
    parser.add_argument(
        "--check_point",
        default="",
        help="Checkpoint name. Valid only if resume is enabled.",
    )

    ## LORA related
    parser.add_argument("--lora", action="store_true")
    parser.add_argument(
        "--lora_rank", type=int, default=8, help="LoRA rank for lora/qlora"
    )
    parser.add_argument(
        "--lora_alpha", type=int, default=16, help="LoRA alpha for lora/qlora"
    )
    parser.add_argument(
        "--lora_dropout", type=float, default=0.05, help="LoRA dropout for lora/qlora"
    )
    parser.add_argument(
        "--lora_target_modules",
        type=str,
        default="all",
        help="If 'default', uses peft defaults. Use 'all' for our best guess for Llama models",
    )

    ## To avoid error
    parser.add_argument(
        "--ts-mode",
        default="best",
        choices=["best", "sample"],
        help="Tree search mode within the evaluation step. `best` uses beam search, `sample` uses sampling.",
    )
    parser.add_argument(
        "--max_length",
        default=2048,
        type=int,
        help="The maximum number of tokens to generate.",
    )
    parser.add_argument(
        "--top-k-cache-steps",
        type=int,
        default=1024,
        help="Number of forward steps to cache top k caches, default 1024 means the whole horizon.",
    )
    parser.add_argument(
        "--width",
        default=3,
        type=int,
        help="The maximum number of children for any node.",
    )
    parser.add_argument(
        "--rerun",
        action="store_true",
        default=False,
        help="If True, rerun if the output file already exists.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        default=False,
        help="If True, rerun if the output file already exists.",
    )
    parser.add_argument("--difficulty", default="hard")

    args = parser.parse_args()

    print(args)

    output_path = os.path.join(
        args.out_path,
        args.arch,
        args.dataset,
        f"ZeroShot_{args.arch}_{args.log_num}_{args.algo}_{args.dataset}_{args.level}",
    )
    

    print("output_path:", output_path)
    os.makedirs(output_path, exist_ok=True)

    # Dataset loading
    if args.dataset == "Ultra":
        dataset = UltraHandler()
        problems = dataset.problems
        problem_indices = range(len(problems))
    elif args.dataset == "APPS":
        if args.level == "intro":
            problem_indices = range(4000, 4100)
        elif args.level == "inter":
            problem_indices = range(100)
        elif args.level == "comp":
            problem_indices = range(3000, 3100)
        dataset = APPSHandler(
            args.data_path, "test", problem_indices, None, 'half'
        )
        problems = dataset.problems
    elif args.dataset == "CodeForce":
        dataset = CodeForceHandler(mode=args.mode)
        problems = dataset.problems
        problem_indices = range(len(problems))
    elif args.dataset == "CodeContest":
        dataset = CodeContestHandler(mode=args.mode, difficulty=args.level)
        problems = dataset.problems
        problem_indices = range(len(problems))
    else:
        raise NotImplementedError
    
    model = ZeroShot(args)

    print("Model set.")
    print(f"Got {len(problems)} problems.")

    main(problem_indices, problems, model, output_path, args.rerun)

    evaluation_res = os.path.join(
        args.res_path, 
        f"ZeroShot_{args.arch}_{args.log_num}_{args.dataset}_{args.level}"
    )

    os.makedirs(evaluation_res, exist_ok=True)
    evaluate(output_path, evaluation_res)
