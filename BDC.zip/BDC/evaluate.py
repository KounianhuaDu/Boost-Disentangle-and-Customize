import numpy as np
import os

import os
import warnings
import json
from tqdm import tqdm

# 忽略warning的输出
warnings.filterwarnings("ignore")


def get_exp_results(res_path, out_path):
    indices = os.listdir(res_path)
    (
        rewards,
        rewards_train,
        times,
        sample_times,
        compile_errors,
        runtime_errors,
        codes,
    ) = ({}, {}, {}, {}, {}, {}, {})

    for idx in tqdm(indices):
        res_dir = os.path.join(res_path, idx, "res.json")
        with open(res_dir) as f:
            result = json.load(f)
            # reward, reward_train, time, sample_time = result['rewards'], result['train rewards'], result['time'], result['sample times']
            reward, reward_train = result["rewards"], result["train rewards"]

        if len(reward) == 0:
            # or (isinstance(time, list) and len(time) == 0):
            print(f"{res_dir} results non-parsable.")
            continue

        if len(reward_train) > 0:
            # sort the training rewards of the samples, get the top n of them
            top_n_indices = np.argsort(reward_train)[::-1][:1]  # arges.n = 1
            # find the one that has the highest test reward
            return_index = max(top_n_indices, key=lambda x: reward[x])
        else:
            return_index = 0

        # add to the list
        rewards[idx] = reward[return_index]
        codes[idx] = result["codes"]

        rewards_train[idx] = reward_train[return_index] if len(reward_train) > 0 else 0
        try:
            compile_errors[idx] = result["compile_error"]
            runtime_errors[idx] = result["runtime_error"]
        except:
            compile_errors[idx] = 0
            runtime_errors[idx] = 0

    results = {
        "rewards": rewards,
        "rewards_train": rewards_train,
        "compile_errors": compile_errors,
        "runtime_errors": runtime_errors,
        "codes": codes,
    }

    # 打印unsolved problem信息
    print("----------------------------------")
    print(f"Unsolved problems:")
    for index in results["rewards"].keys():
        if results["rewards"][index] != 1.0:
            print("\n----")
            print(f"reward: {results['rewards'][index]}")
            print(f"unsolved problem {index}")
            print(results["codes"][index])
    """
    Print the results and log, also return it possibly for analysis
    """
    rewards, rewards_train = results["rewards"], results["rewards_train"]

    # ignore the keys and get the values, and convert to np.array
    convert_to_array = lambda result: np.array(list(result.values()))

    rewards, rewards_train = map(
        lambda x: convert_to_array(x), [rewards, rewards_train]
    )

    stat = {
        "pass_rate": 100 * np.mean(rewards),
        "ac": 100 * np.mean(np.array(rewards) == 1.0),
        "training_pass_rate": (
            100 * np.mean(rewards_train) if None not in rewards_train else None
        ),
        "training_ac": (
            100 * np.mean(rewards_train == 1.0) if None not in rewards_train else None
        ),
    }

    print(f"Got {len(rewards)} problems.")
    print(f"PassRate: {stat['pass_rate']:.4f}%; AC: {stat['ac']:.4f}%")

    # with open(os.path.join(out_path, "AllRes.json"), "w") as f:
    #     try:
    #         json.dump(stat, f)
    #     except Exception as e:
    #         print(f"Couldn't save all results.\n{e}")


if __name__ == "__main__":
    get_exp_results(
        "/home/jzchen/ML/Multi-Teacher-Tree-Alignment/inference_res/CodeContest/DebateMCTS_2_0_[2]_hard",
        None,
    )
