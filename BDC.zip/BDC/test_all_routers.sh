python load_router_for_test.py --dataset APPS --level intro --arch llama3
python load_router_for_test.py --dataset APPS --level inter --arch llama3
