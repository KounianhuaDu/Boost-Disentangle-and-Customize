import json
import os
import argparse

def post(out_dir):
    with open(os.path.join(out_dir, "sft_data.json"), "r") as f:
        sft_data = json.load(f)
    lines = []
    for line in sft_data:
        input = line['input'].split('-----Clues-----')[1]
        output = line['output']
        lines.append({"input": input, "output": output})
    with open(os.path.join(out_dir, "post.json"), "w") as f:
        json.dump(lines, f)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parser For Arguments",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--in_root", default="../train_trace/")
    parser.add_argument("--out_root", default="../train_data")
    parser.add_argument("--final_root", default="../train_data/final")
    parser.add_argument("--trace")

    args = parser.parse_args()

    
    final_path = os.path.join(
        args.final_root, args.trace
    )
    
    print(args)

    post(final_path)


