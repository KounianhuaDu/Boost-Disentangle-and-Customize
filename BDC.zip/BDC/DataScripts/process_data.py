import json
import os
import argparse
from tqdm import tqdm
import numpy as np
import dgl
import torch

import sys
sys.path.append("..")
from data_handling import CodeContestHandler

def extract(
    decision_to_chance, chance_to_decision, chance_features, decision_features, res
):
    # chance_features: ucb, p_ucb, var_p_ucb, action, prob
    # decision_features: state, reward
    best_code = res["codes"]
    rewards = res["train rewards"]

    dc_src = []
    dc_dst = []
    for dc_edge in decision_to_chance:
        dc_src.append(dc_edge[0])
        dc_dst.append(dc_edge[1])

    cd_src = []
    cd_dst = []
    for cd_edge in chance_to_decision:
        cd_src.append(cd_edge[0])
        cd_dst.append(cd_edge[1])

    data_dict = {
        ("decision", "dc", "chance"): (dc_src, dc_dst),
        ("chance", "cd", "decision"): (cd_src, cd_dst),
    }
    hg = dgl.heterograph(data_dict)
    assert len(list(hg.in_edges(torch.tensor([0]), etype='cd')[0])) == 0  # make sure the root node
    decision_nodes = hg.nodes('decision')
    preference_pairs = []  # (x, y1, y2)
    best_state = ''
    best_val = -1
    mtta_data = []

    for node in decision_nodes:
        ucb_sum = 0
        children = hg.out_edges(node, etype='dc')[1]
        
        for child in children:
            ucb_sum += chance_features[str(child.item())]['var_p_ucb']
        for child in children:
            chance_features[str(child.item())]['ucb_weight'] = chance_features[str(child.item())]['var_p_ucb']/ucb_sum

    for node in decision_nodes:
        val = decision_features[str(node.item())]["value"]
        if val is None:
            val = 0
            val = 0
        if val > best_val:
            best_val = val
            best_state = decision_features[str(node.item())]['state']

        x = decision_features[str(node.item())]['state']
        children = hg.out_edges(node, etype='dc')[1]
        good_actions = []
        bad_actions = []

        for child in children:
            action = chance_features[str(child.item())]['action']
            
            next_decisions = hg.successors(child, etype='cd')
            if len(next_decisions) > 0:
                next_decision = next_decisions[0]
                next_val = decision_features[str(next_decision.item())]['value']
                if next_val is None:
                    next_val = 0
            else:
                next_val = chance_features[str(child.item())]['var_p_ucb']
                if next_val is None:
                    next_val = 0
                by_model = chance_features[str(child.item())]['by_model']
                ucb_weight = chance_features[str(child.item())]['ucb_weight']

                mtta_data.append([x, action, ucb_weight, next_val, by_model])

            if next_val > val:
                good_actions.append(action)
            else:
                bad_actions.append(action)
                
        for good_action in good_actions:
            for bad_action in bad_actions:
                preference_pairs.append((x, good_action, bad_action))

    return preference_pairs, (best_state, best_code), mtta_data


def extract_pairs(datapath, outpath):

    problem_idxs = os.listdir(datapath)
    #print(problem_idxs)
    for problem_dir_ in tqdm(problem_idxs):
        if not problem_dir_.isdigit():
            continue
        problem_dir = os.path.join(datapath, problem_dir_)
        with open(os.path.join(problem_dir, "res.json"), "rb") as f:
            res = json.load(f)
            reward, reward_train = res['rewards'], res['train rewards']
            if len(reward) == 0:
                print(f"{problem_dir} results non-parsable.")
                continue
            if len(reward_train) > 0:
                top_n_indices = np.argsort(reward_train)[::-1][:1]  # arges.n = 1
                return_index = max(top_n_indices, key=lambda x: reward[x])
            else:
                return_index = 0
            passrate = reward[return_index]
            if passrate < 1:
                print(f"{problem_dir} passrate:{passrate}, Skip.")
                continue

        with open(os.path.join(problem_dir, "trace.json"), "rb") as f:
            data = json.load(f)
            decision_to_chance = data["decision_to_chance"]
            chance_to_decision = data["chance_to_decision"]
            chance_features = data["chance_features"]
            decision_features = data["decision_features"]

        preference_pairs, sft_data, mtta_data = extract(
            decision_to_chance,
            chance_to_decision,
            chance_features,
            decision_features,
            res,
        )

        os.makedirs(os.path.join(outpath, problem_dir_), exist_ok=True)
        with open(os.path.join(outpath, problem_dir_, "train_data.json"), "w") as f:
            json.dump({"StepDPO": preference_pairs, "SFT": sft_data, "MTTA": mtta_data}, f)

def code2thought(problem):
    rationale_instruct = """
You will be given a problem desciption.\n
Please analyze the problem and generate step-by-step clues of how to solve the problem with executable python code.\n
The problem:\n
{}\n""".format(problem)
    rationale_instruct += """
An example of step-by-step clues for finding the longest palindrome substring is displayed below:\n
```json
[
{"Clue of Step 1": "For a substring, if it is a palindrome and the length is greater than 2, it is still a palindrome after the first and last letters are removed. According to this idea, we can use dynamic programming to solve this problem."},
{"Clue of Step 2": "Then we should consider the state transition function. We use P(i,j) to indicate whether the string composed of the i-th to j-th letters of the string s (denoted as as s[i:j]) is a palindrome string. s[i:j] is a palindrome only if s[i+1:j−1] is a palindrome and the i and j letters of s are the same."},
{"Clue of Step 3": "We also need to consider the boundary conditions in dynamic programming. For a substring of length 1, it is obviously a palindrome string; For a substring of length 2, it is a palindrome as long as its two letters are the same."},
{"Clue of Step 4": "We also need to consider the the cyclic order of dynamic programming. In the state transition equation, we are moving from a shorter string to a longer string."},
{"Clue of Step 5": "The final answer is the maximum length of the valid sub-strings."}
]
```
You can refer to the following example and generate step-by-step clues for the given problem.\n

-----Clues-----
"""
    return rationale_instruct

def thought2code(problem, cot):
    prompt = """You will be given a problem desciption.\n
Please analyze the problem and the corresponding clues to generate executable python code to solve the problem.\n
The problem:\n{}
\n The clues:\n{}
\n""".format(problem, cot)
    return prompt
        
def process_data(data_dir, out_dir, dataset):
    sft_data = []
    p2t_data = []
    t2s_data = []
    dpo_data = []
    mtta_data = []
    post = []
    data_to_group = []
    dirs = os.listdir(data_dir)
    
    code_dataset = CodeContestHandler(mode='train', data_path="../data/CodeContest")
    code_problems = code_dataset.problems
    
    print(dataset)
    for dir in dirs:
        # print(dir)
        file_name = os.path.join(data_dir, dir, "train_data.json")
        
        if dataset == 'APPS':
            prompt_path = os.path.join('../data', f"APPS/test/{int(dir):04d}", "question.txt")
            if not os.path.exists(prompt_path):
                continue

            input_prompt = "\nQUESTION:\n"
            with open(prompt_path, "r") as f:
                data = f.readlines()
                data = "".join(data)
            input_prompt += data

            #print(input_prompt)
        elif dataset == 'CodeContest':
            input_prompt = code_problems[int(dir)]["prompt"]
            
        with open(file_name, "r") as f:
            data = json.load(f)
            sft_line = data["SFT"]
            dpo_line = data["StepDPO"]
            mtta_line = data["MTTA"]

            # Code2Thought
            c2t_input = code2thought(input_prompt)
            c2t_output = sft_line[0].split('-----Clues-----')[1]
            sft_data.append({"input": c2t_input, "output": c2t_output})
            p2t_data.append({"input": c2t_input, "output": c2t_output})
            
            # Thought2Code
            t2c_input = thought2code(input_prompt, c2t_output)
            sft_data.append({"input": t2c_input, "output": sft_line[1]})
            t2s_data.append({"input": t2c_input, "output": sft_line[1]})
            
            data_to_group.append({"idx": int(dir), 
                                  "p2t_input": c2t_input, 
                                  "p2t_output": c2t_output,
                                  "t2s_input": t2c_input,
                                  "t2s_output": sft_line[1]
                                  })

            post.append({"idx": dir, "input": sft_line[0].split('-----Clues-----')[1], "output": sft_line[1]})
            dpo_data.extend([{"prompt": x[0], "chosen": x[1], "rejected": x[2]} for x in dpo_line])
            mtta_data.extend([{"state": x[0], "action": x[1], "var_p_ucb": x[2], "by_model": x[3]} for x in mtta_line])

    print("Length of DPO data:", len(dpo_data))
    print("Length of SFT data:", len(sft_data))
    print("Length of MTTA data:", len(mtta_data))
    
    with open(os.path.join(out_dir, "sft_data.json"), "w") as f:
        json.dump(sft_data, f)
    with open(os.path.join(out_dir, "p2t_data.json"), "w") as f:
        json.dump(p2t_data, f)
    with open(os.path.join(out_dir, "t2s_data.json"), "w") as f:
        json.dump(t2s_data, f)
    with open(os.path.join(out_dir, "data_to_group.json"), "w") as f:
        json.dump(data_to_group, f)

    with open(os.path.join(out_dir, "post.json"), "w") as f:
        json.dump(post, f)
    with open(os.path.join(out_dir, "dpo_data.json"), "w") as f:
        json.dump(dpo_data, f)
    with open(os.path.join(out_dir, "mtta_data.json"), "w") as f:
        json.dump(mtta_data, f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parser For Arguments",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--in_root", default="../train_trace/APPS")
    parser.add_argument("--dataset", default="APPS")
    parser.add_argument("--out_root", default="../train_data")
    parser.add_argument("--final_root", default="../train_data/final")
    parser.add_argument("--trace")

    args = parser.parse_args()

    data_path = os.path.join(
        args.in_root, args.trace
    )
    out_path = os.path.join(
        args.out_root, args.trace
    )
    final_path = os.path.join(
        args.final_root, args.trace
    )
    os.makedirs(out_path, exist_ok=True)
    os.makedirs(final_path, exist_ok=True)

    print(args)

    extract_pairs(data_path, out_path)
    process_data(out_path, final_path, args.dataset)


