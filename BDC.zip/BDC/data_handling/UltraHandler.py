import os
import re
import json
import pandas as pd


def get_test_cases(public_testcases, private_testcases):
    in_out_len = len(public_testcases["input"]) + len(private_testcases["input"])
    public_test_cases = in_out_len // 2
    inputs = public_testcases["input"] + private_testcases["input"]
    outputs = public_testcases["output"] + private_testcases["output"]
    train_in_outs, test_in_outs = {}, {}
    private_test_cases = in_out_len - public_test_cases
    if public_test_cases < 1 or private_test_cases < 1:
        # print(f"Not enough test cases: {public_test_cases}, {private_test_cases}.")
        return None, None
    train_in_outs["inputs"] = inputs[:public_test_cases]
    train_in_outs["outputs"] = outputs[:public_test_cases]
    test_in_outs["inputs"] = inputs[public_test_cases:]
    test_in_outs["outputs"] = outputs[public_test_cases:]
    return train_in_outs, test_in_outs


def extract_input_output(traj):
    example_section = re.search(
        r"(?:Examples:|Examples|Example:)\s+([\s\S]*)", traj, re.IGNORECASE
    )
    if example_section:
        example_text = example_section.group(1)
        # Adjust regex to handle both "Input"/"SAMPLE INPUT" and "Output"/"SAMPLE OUTPUT" with or without colons
        input_matches = re.findall(
            r"(?:Input|SAMPLE INPUT)[:\s]*\n([\s\S]*?)\n\n(?:Output|SAMPLE OUTPUT)[:\s]*",
            example_text,
            re.IGNORECASE,
        )
        output_matches = re.findall(
            r"(?:Output|SAMPLE OUTPUT)[:\s]*\n([\s\S]*?)(?:\n\n|$)",
            example_text,
            re.IGNORECASE,
        )
        # Process matches to clean up whitespace and organize in lists
        input_list = [item.strip() for item in input_matches]
        output_list = [item.strip() for item in output_matches]
        return input_list, output_list
    else:
        return None, None


class UltraHandler:
    def __init__(
        self,
        data_path="../data/Ultra/0000_pair.parquet",
        public_cases_type="half",
    ):
        remained = 0
        self.problems = []
        self.all = pd.read_parquet(data_path)
        for idx, problem in self.all.iterrows():
            problem_instance = {}
            problem_instance["index"] = idx
            problem_instance["id"] = problem["id"]
            problem_instance["prompt"] = (
                "\nQUESTION:\n" + problem["trajectory"][0]["value"] + "\nANSWER:\n"
            )
            problem_instance["cot"] = re.findall(r"Step \d+:\s+(.*)", problem["chosen"])
            if problem_instance["cot"] == []:
                continue
            problem_instance["code_type"] = "standard_input"
            problem_instance["method_name"] = None
            input_list, output_list = extract_input_output(
                problem["trajectory"][0]["value"]
            )
            if input_list == None:
                continue
            else:
                problem_instance["train_in_outs"] = {
                    "inputs": input_list,
                    "outputs": output_list,
                }
                problem_instance["test_in_outs"] = {
                    "inputs": input_list,
                    "outputs": output_list,
                }
            remained += 1
            self.problems.append(problem_instance)
        print(f"{remained} questions remain.")


if __name__ == "__main__":
    a = UltraHandler()
    problems = a.problems
    prompt = problems[0]["prompt"]
    cot = problems[0]['cot']
    print(prompt)
    print(cot)
    print(len(problems))
    

