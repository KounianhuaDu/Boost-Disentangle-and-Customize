import os
import json


def get_test_cases(input_output, public_cases_type, mode):
    in_outs = input_output
    if mode == "train":
        if len(in_outs["inputs"]) == 1 and "\n" in in_outs["inputs"][0]:
            tmp = in_outs["inputs"][0].split("\n")
            in_outs["inputs"] = [val + "\n" for val in tmp][:-1]
            tmp = in_outs["outputs"][0].split("\n")
            in_outs["outputs"] = [val + "\n" for val in tmp][:-1]

    in_out_len = len(in_outs["inputs"])

    train_in_outs, test_in_outs = {}, {}
    if public_cases_type == "half":
        # split evenly by default
        public_test_cases = in_out_len // 2
    elif public_cases_type.isdigit():
        public_test_cases = int(public_cases_type)
    else:
        raise Exception(f"Can't understand public_test_cases {public_cases_type}")
    private_test_cases = in_out_len - public_test_cases

    if public_test_cases < 1 or private_test_cases < 1:
        print(f"Not enough test cases: {public_test_cases}, {private_test_cases}.")
        return None, None

    train_in_outs["inputs"] = in_outs["inputs"][:public_test_cases]
    train_in_outs["outputs"] = in_outs["outputs"][:public_test_cases]
    test_in_outs["inputs"] = in_outs["inputs"][public_test_cases:]
    test_in_outs["outputs"] = in_outs["outputs"][public_test_cases:]

    return train_in_outs, test_in_outs


class HuggingfaceAPPSHandler:
    def __init__(
        self,
        data_path,
        mode,
        problem_indices,
        difficulty="introductory",
        public_cases_type="half",
    ):
        raw_data = []
        self.problems = []
        with open(os.path.join(data_path, f"{mode}.jsonl"), "r") as f:
            for i, line in enumerate(f):
                if i in problem_indices:
                    raw_data.append((i, json.loads(line)))

        if difficulty is not None:
            raw_data = [
                (i, d)
                for i, d in raw_data
                if d["metadata"]["difficulty"] == difficulty
                and d["input_output"] is not None
            ]

        for idx, problem in raw_data:
            problem_instance = {}
            problem_instance["index"] = idx
            input_prompt = "\nQUESTION:\n" + problem["question"]

            if isinstance(problem["input_output"], str):
                problem["input_output"] = json.loads(problem["input_output"])

            if not problem["input_output"].get("fn_name"):
                input_prompt += "\nUse Standard Input format"  # \n"
                problem_instance["code_type"] = "standard_input"
                problem_instance["method_name"] = None
            else:
                input_prompt += "\nUse Call-Based format"  # \n"
                problem_instance["code_type"] = "call_based"
                problem_instance["method_name"] = problem["input_output"].get("fn_name")

            input_prompt += "\nANSWER:\n"
            problem_instance["prompt"] = input_prompt

            # test cases for train and test
            train_in_outs, test_in_outs = get_test_cases(
                problem["input_output"], public_cases_type, mode
            )
            if not train_in_outs:
                continue

            problem_instance["train_in_outs"] = train_in_outs
            problem_instance["test_in_outs"] = test_in_outs
            self.problems.append(problem_instance)
