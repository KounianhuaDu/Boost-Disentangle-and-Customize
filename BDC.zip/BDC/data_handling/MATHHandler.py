import os
import json

class MATHHandler:
    def __init__(self, data_path, platforms=None):
        self.problems = []
        if platforms is None:
            # List all subdirectories in MATH/ as platforms
            platforms = [
                name for name in os.listdir(os.path.join(data_path, 'MATH'))
                if os.path.isdir(os.path.join(data_path, 'MATH', name))
            ]
        for platform in platforms:
            platform_path = os.path.join(data_path, 'MATH', platform)
            for filename in os.listdir(platform_path):
                if 'prompt' or 'template' in filename:
                    continue
                if filename.endswith('.json') or filename.endswith('.jsonl'):
                    filepath = os.path.join(platform_path, filename)
                    with open(filepath, 'r') as f:
                        data = json.load(f)
                        # Assuming data is a list of problems
                        if 'AQuA' in filename:
                            self.process_AQuA(data)
                        elif 'challenge' in filename or 'deepmind' in filename or 'sat' in filename or 'simuleq' in filename:
                            self.process_challenge_or_deepmind_or_sat_or_simuleq(data)
                        elif 'bbh' in filename:
                            self.process_bbh(data)
                        elif 'math' in filename:
                            self.process_math(data) # for math, pass. unbox operation needed.
                        elif 'mmlu' in filename and not 'mmlu_pro' in filename:
                            self.process_mmlu(data)
                        elif 'mmlu' in filename and 'mmlu_pro' in filename:
                            self.process_mmlu_pro(data)
                        elif 'numglue' in filename:
                            self.process_numglue(data)
                        elif 'SVAMP' in filename:
                            self.process_SVAMP(data)
                        elif 'theoremqa' in filename:
                            self.process_theoremqa(data)
                        else:
                            raise NotImplementedError


    def process_AQuA(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'AQuA'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['correct']]
            }
            # Optionally include rationale if needed
            problem_instance['rationale'] = data.get('rationale', '')
            problem_instance['options'] = data.get('options', [])
            self.problems.append(problem_instance)

    def process_challenge_or_deepmind_or_sat_or_simuleq(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'challenge_or_deepmind_or_sat_or_simuleq'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['answer']]
            }
            self.problems.append(problem_instance)

    def process_bbh(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'bbh'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['answer']]
            }
            # Optionally include task type if needed
            problem_instance['task'] = problem.get('task', '')
            self.problems.append(problem_instance)

    def process_math(self, data):
        pass
        # # need to unbox the final answer
        # for idx, problem in enumerate(data):
        #     problem_instance = {}
        #     problem_instance['sub_dataset'] = 'math'
        #     problem_instance['index'] = idx
        #     input_prompt = "\nQUESTION:\n"
        #     input_prompt += problem['question']
        #     input_prompt += "\nANSWER:\n"
        #     problem_instance['prompt'] = input_prompt
        #     # For compatibility, create empty train_in_outs
        #     problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
        #     # Include the correct answer in test_in_outs
        #     problem_instance['test_in_outs'] = {
        #         'inputs': [''],
        #         'outputs': [problem['answer']]
        #     }
        #     # Optionally include level or type if needed
        #     problem_instance['level'] = problem.get('level', '')
        #     problem_instance['type'] = problem.get('type', '')
        #     self.problems.append(problem_instance)

    def process_mmlu(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'mmlu'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['question']
            input_prompt += "\nCHOICES:\n"
            for idx, choice in enumerate(problem['choices']):
                input_prompt += f"{idx}. {choice}\n"
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['answer']]
            }
            # Optionally include subject or choices if needed
            problem_instance['subject'] = problem.get('subject', '')
            problem_instance['choices'] = problem.get('choices', [])
            self.problems.append(problem_instance)

    def process_mmlu_pro(self, data):
        # skip prompt.py needed
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'mmlu_pro'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['answer']]
            }
            # Optionally include src, task or question_id if needed
            problem_instance['src'] = problem.get('src', '')
            problem_instance['task'] = problem.get('task', '')
            problem_instance['question_id'] = problem.get('question_id', '')
            self.problems.append(problem_instance)

    def process_numglue(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'numglue'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['answer']]
            }
            # Optionally include type if needed
            problem_instance['type'] = problem.get('type', '')
            self.problems.append(problem_instance)

    def process_SVAMP(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'SVAMP'
            problem_instance['index'] = idx
            input_prompt = "\nCONTEXT:\n"
            input_prompt += problem['Body']
            input_prompt += "\nQUESTION:\n"
            input_prompt += problem['Question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['Answer']]
            }
            # Optionally include ID, Body, Equation, Type if needed
            problem_instance['ID'] = problem.get('ID', '')
            problem_instance['Body'] = problem.get('Body', '')
            problem_instance['Equation'] = problem.get('Equation', '')
            problem_instance['Type'] = problem.get('Type', '')
            self.problems.append(problem_instance)

    def process_theoremqa(self, data):
        for idx, problem in enumerate(data):
            problem_instance = {}
            problem_instance['sub_dataset'] = 'theoremqa'
            problem_instance['index'] = idx
            input_prompt = "\nQUESTION:\n"
            input_prompt += problem['Question']
            input_prompt += "\nANSWER:\n"
            problem_instance['prompt'] = input_prompt
            # For compatibility, create empty train_in_outs
            problem_instance['train_in_outs'] = {'inputs': [], 'outputs': []}
            # Include the correct answer in test_in_outs
            problem_instance['test_in_outs'] = {
                'inputs': [''],
                'outputs': [problem['Answer']]
            }
            # Optionally include Answer_type, Picture, source, id, explanation, theorem, subfield, field if needed
            problem_instance['Answer_type'] = problem.get('Answer_type', '')
            problem_instance['Picture'] = problem.get('Picture', '')
            problem_instance['source'] = problem.get('source', '')
            problem_instance['id'] = problem.get('id', '')
            problem_instance['explanation'] = problem.get('explanation', '')
            problem_instance['subfield'] = problem.get('subfield', '')
            problem_instance['field'] = problem.get('field', '')
            problem_instance['theorem'] = problem.get('theorem', '')
            self.problems.append(problem_instance)
